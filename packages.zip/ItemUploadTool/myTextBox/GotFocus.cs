﻿namespace myTextBox
{
    internal class GotFocus
    {
    }
}