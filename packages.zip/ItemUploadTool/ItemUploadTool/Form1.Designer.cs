﻿namespace ItemUploadTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.t1cleardata = new System.Windows.Forms.Button();
            this.t1reset = new System.Windows.Forms.Button();
            this.t1copy = new System.Windows.Forms.Button();
            this.t1undoadd = new System.Windows.Forms.Button();
            this.t1addclear = new System.Windows.Forms.Button();
            this.t1undosort = new System.Windows.Forms.Button();
            this.t1add = new System.Windows.Forms.Button();
            this.t1template = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Action = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemorBranch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.branchplant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shortid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thirditemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptiontwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.searchtext = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subcomm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sizeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sizetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sched = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ratgec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specgrade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laborgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mtlgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbcodeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbcodetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbcodethree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wtum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.voluom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lotproctype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countryreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockingtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shelfdays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surfacearea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.templateid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.projmfgreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t1salbl = new System.Windows.Forms.Label();
            this.t1wtlbl = new System.Windows.Forms.Label();
            this.t1gllbl = new System.Windows.Forms.Label();
            this.t1matlbl = new System.Windows.Forms.Label();
            this.t1sa = new System.Windows.Forms.TextBox();
            this.t1wt = new System.Windows.Forms.TextBox();
            this.t1gl = new System.Windows.Forms.TextBox();
            this.t1mat = new System.Windows.Forms.TextBox();
            this.t1desclbl = new System.Windows.Forms.Label();
            this.t1pcodelbl = new System.Windows.Forms.Label();
            this.t1desc = new System.Windows.Forms.TextBox();
            this.t1pcode = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.t2cleardata = new System.Windows.Forms.Button();
            this.t2copy = new System.Windows.Forms.Button();
            this.t2reset = new System.Windows.Forms.Button();
            this.t2undoadd = new System.Windows.Forms.Button();
            this.t2undosort = new System.Windows.Forms.Button();
            this.t2addclear = new System.Windows.Forms.Button();
            this.t2add = new System.Windows.Forms.Button();
            this.t2convertlbl = new System.Windows.Forms.Label();
            this.t2template = new System.Windows.Forms.ComboBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.t2Action = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2ItemorBranch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2branchplant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2shortid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2itemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2thirditemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2descriptionone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2descriptiontwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2searchtext = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2comm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2subcomm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2sizeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2sizetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2sched = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2ratgec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2specgrade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2laborgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2mtlgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2pbcodeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2pbcodetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2pbcodethree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2uom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2wtum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2voluom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2classcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2lotproctype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2countryreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2stockingtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2lnty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2shelfdays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2weightprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2surfacearea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2templateid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2projmfgreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2salbl = new System.Windows.Forms.Label();
            this.t2wtlbl = new System.Windows.Forms.Label();
            this.t2gllbl = new System.Windows.Forms.Label();
            this.t2matlbl = new System.Windows.Forms.Label();
            this.t2sa = new System.Windows.Forms.TextBox();
            this.t2wt = new System.Windows.Forms.TextBox();
            this.t2gl = new System.Windows.Forms.TextBox();
            this.t2mat = new System.Windows.Forms.TextBox();
            this.t2desclbl = new System.Windows.Forms.Label();
            this.t2pcodelbl = new System.Windows.Forms.Label();
            this.t2desc = new System.Windows.Forms.TextBox();
            this.t2pcode = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1179, 711);
            this.tabControl1.TabIndex = 21;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.t1cleardata);
            this.tabPage1.Controls.Add(this.t1reset);
            this.tabPage1.Controls.Add(this.t1copy);
            this.tabPage1.Controls.Add(this.t1undoadd);
            this.tabPage1.Controls.Add(this.t1addclear);
            this.tabPage1.Controls.Add(this.t1undosort);
            this.tabPage1.Controls.Add(this.t1add);
            this.tabPage1.Controls.Add(this.t1template);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.t1salbl);
            this.tabPage1.Controls.Add(this.t1wtlbl);
            this.tabPage1.Controls.Add(this.t1gllbl);
            this.tabPage1.Controls.Add(this.t1matlbl);
            this.tabPage1.Controls.Add(this.t1sa);
            this.tabPage1.Controls.Add(this.t1wt);
            this.tabPage1.Controls.Add(this.t1gl);
            this.tabPage1.Controls.Add(this.t1mat);
            this.tabPage1.Controls.Add(this.t1desclbl);
            this.tabPage1.Controls.Add(this.t1pcodelbl);
            this.tabPage1.Controls.Add(this.t1desc);
            this.tabPage1.Controls.Add(this.t1pcode);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1171, 685);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Fittings";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(800, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(369, 184);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // t1cleardata
            // 
            this.t1cleardata.Location = new System.Drawing.Point(259, 186);
            this.t1cleardata.Name = "t1cleardata";
            this.t1cleardata.Size = new System.Drawing.Size(102, 28);
            this.t1cleardata.TabIndex = 20;
            this.t1cleardata.Text = "Clear Data";
            this.t1cleardata.UseVisualStyleBackColor = true;
            this.t1cleardata.Click += new System.EventHandler(this.t1cleardata_Click);
            // 
            // t1reset
            // 
            this.t1reset.Location = new System.Drawing.Point(651, 89);
            this.t1reset.Name = "t1reset";
            this.t1reset.Size = new System.Drawing.Size(102, 28);
            this.t1reset.TabIndex = 19;
            this.t1reset.Text = "Reset Fields";
            this.t1reset.UseVisualStyleBackColor = true;
            this.t1reset.Click += new System.EventHandler(this.t1reset_Click);
            // 
            // t1copy
            // 
            this.t1copy.Location = new System.Drawing.Point(367, 186);
            this.t1copy.Name = "t1copy";
            this.t1copy.Size = new System.Drawing.Size(102, 28);
            this.t1copy.TabIndex = 18;
            this.t1copy.Text = "Copy";
            this.t1copy.UseVisualStyleBackColor = true;
            this.t1copy.Click += new System.EventHandler(this.t1copy_Click);
            // 
            // t1undoadd
            // 
            this.t1undoadd.Location = new System.Drawing.Point(151, 186);
            this.t1undoadd.Name = "t1undoadd";
            this.t1undoadd.Size = new System.Drawing.Size(102, 28);
            this.t1undoadd.TabIndex = 17;
            this.t1undoadd.Text = "Undo Add";
            this.t1undoadd.UseVisualStyleBackColor = true;
            // 
            // t1addclear
            // 
            this.t1addclear.Location = new System.Drawing.Point(39, 186);
            this.t1addclear.Name = "t1addclear";
            this.t1addclear.Size = new System.Drawing.Size(102, 28);
            this.t1addclear.TabIndex = 16;
            this.t1addclear.Text = "Add_Clear";
            this.t1addclear.UseVisualStyleBackColor = true;
            // 
            // t1undosort
            // 
            this.t1undosort.Location = new System.Drawing.Point(151, 138);
            this.t1undosort.Name = "t1undosort";
            this.t1undosort.Size = new System.Drawing.Size(102, 28);
            this.t1undosort.TabIndex = 15;
            this.t1undosort.Text = "Undo Sort";
            this.t1undosort.UseVisualStyleBackColor = true;
            this.t1undosort.Click += new System.EventHandler(this.t1undosort_Click);
            // 
            // t1add
            // 
            this.t1add.Location = new System.Drawing.Point(38, 138);
            this.t1add.Name = "t1add";
            this.t1add.Size = new System.Drawing.Size(102, 28);
            this.t1add.TabIndex = 14;
            this.t1add.Text = "Add";
            this.t1add.UseVisualStyleBackColor = true;
            this.t1add.Click += new System.EventHandler(this.t1add_Click);
            // 
            // t1template
            // 
            this.t1template.FormattingEnabled = true;
            this.t1template.Location = new System.Drawing.Point(395, 96);
            this.t1template.Name = "t1template";
            this.t1template.Size = new System.Drawing.Size(146, 21);
            this.t1template.TabIndex = 13;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Action,
            this.ItemorBranch,
            this.branchplant,
            this.shortid,
            this.itemnumber,
            this.thirditemnumber,
            this.descriptionone,
            this.descriptiontwo,
            this.searchtext,
            this.comm,
            this.subcomm,
            this.sizeone,
            this.sizetwo,
            this.sched,
            this.ratgec,
            this.specgrade,
            this.laborgrp,
            this.mtlgrp,
            this.pbcodeone,
            this.pbcodetwo,
            this.pbcodethree,
            this.uom,
            this.wtum,
            this.voluom,
            this.classcode,
            this.lotproctype,
            this.countryreqd,
            this.stockingtype,
            this.lnty,
            this.shelfdays,
            this.weightprice,
            this.surfacearea,
            this.templateid,
            this.projmfgreqd});
            this.dataGridView1.Location = new System.Drawing.Point(8, 237);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1162, 440);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Action
            // 
            this.Action.HeaderText = "Action";
            this.Action.Name = "Action";
            // 
            // ItemorBranch
            // 
            this.ItemorBranch.HeaderText = "Item or Branch";
            this.ItemorBranch.Name = "ItemorBranch";
            // 
            // branchplant
            // 
            this.branchplant.HeaderText = "Branch Plant";
            this.branchplant.Name = "branchplant";
            // 
            // shortid
            // 
            this.shortid.HeaderText = "Short ID";
            this.shortid.Name = "shortid";
            // 
            // itemnumber
            // 
            this.itemnumber.HeaderText = "Item Number";
            this.itemnumber.Name = "itemnumber";
            // 
            // thirditemnumber
            // 
            this.thirditemnumber.HeaderText = "3rd Item Number";
            this.thirditemnumber.Name = "thirditemnumber";
            // 
            // descriptionone
            // 
            this.descriptionone.HeaderText = "Description 1";
            this.descriptionone.Name = "descriptionone";
            // 
            // descriptiontwo
            // 
            this.descriptiontwo.HeaderText = "Description 2";
            this.descriptiontwo.Name = "descriptiontwo";
            // 
            // searchtext
            // 
            this.searchtext.HeaderText = "Search Text";
            this.searchtext.Name = "searchtext";
            // 
            // comm
            // 
            this.comm.HeaderText = "Comm";
            this.comm.Name = "comm";
            // 
            // subcomm
            // 
            this.subcomm.HeaderText = "Sub Comm";
            this.subcomm.Name = "subcomm";
            // 
            // sizeone
            // 
            this.sizeone.HeaderText = "Size 1";
            this.sizeone.Name = "sizeone";
            // 
            // sizetwo
            // 
            this.sizetwo.HeaderText = "Size 2";
            this.sizetwo.Name = "sizetwo";
            // 
            // sched
            // 
            this.sched.HeaderText = "Sch";
            this.sched.Name = "sched";
            // 
            // ratgec
            // 
            this.ratgec.HeaderText = "Rating";
            this.ratgec.Name = "ratgec";
            // 
            // specgrade
            // 
            this.specgrade.HeaderText = "Spec Grade";
            this.specgrade.Name = "specgrade";
            // 
            // laborgrp
            // 
            this.laborgrp.HeaderText = "Labor Grp";
            this.laborgrp.Name = "laborgrp";
            // 
            // mtlgrp
            // 
            this.mtlgrp.HeaderText = "Mtl Grp";
            this.mtlgrp.Name = "mtlgrp";
            // 
            // pbcodeone
            // 
            this.pbcodeone.HeaderText = "P/B Code1";
            this.pbcodeone.Name = "pbcodeone";
            // 
            // pbcodetwo
            // 
            this.pbcodetwo.HeaderText = "P/B Code2";
            this.pbcodetwo.Name = "pbcodetwo";
            // 
            // pbcodethree
            // 
            this.pbcodethree.HeaderText = "P/B Code3";
            this.pbcodethree.Name = "pbcodethree";
            // 
            // uom
            // 
            this.uom.HeaderText = "Uom";
            this.uom.Name = "uom";
            // 
            // wtum
            // 
            this.wtum.HeaderText = "Wt UM";
            this.wtum.Name = "wtum";
            // 
            // voluom
            // 
            this.voluom.HeaderText = "Vol UOM";
            this.voluom.Name = "voluom";
            // 
            // classcode
            // 
            this.classcode.HeaderText = "Class Code";
            this.classcode.Name = "classcode";
            // 
            // lotproctype
            // 
            this.lotproctype.HeaderText = "Lot Proc Type";
            this.lotproctype.Name = "lotproctype";
            // 
            // countryreqd
            // 
            this.countryreqd.HeaderText = "Country Reqd";
            this.countryreqd.Name = "countryreqd";
            // 
            // stockingtype
            // 
            this.stockingtype.HeaderText = "Stocking Type";
            this.stockingtype.Name = "stockingtype";
            // 
            // lnty
            // 
            this.lnty.HeaderText = "Ln Ty";
            this.lnty.Name = "lnty";
            // 
            // shelfdays
            // 
            this.shelfdays.HeaderText = "Shelf Days";
            this.shelfdays.Name = "shelfdays";
            // 
            // weightprice
            // 
            this.weightprice.HeaderText = "Weight/Price";
            this.weightprice.Name = "weightprice";
            // 
            // surfacearea
            // 
            this.surfacearea.HeaderText = "Surface Area";
            this.surfacearea.Name = "surfacearea";
            // 
            // templateid
            // 
            this.templateid.HeaderText = "Template ID";
            this.templateid.Name = "templateid";
            // 
            // projmfgreqd
            // 
            this.projmfgreqd.HeaderText = "Prof Mfg Reqd";
            this.projmfgreqd.Name = "projmfgreqd";
            // 
            // t1salbl
            // 
            this.t1salbl.AutoSize = true;
            this.t1salbl.Location = new System.Drawing.Point(204, 81);
            this.t1salbl.Name = "t1salbl";
            this.t1salbl.Size = new System.Drawing.Size(21, 13);
            this.t1salbl.TabIndex = 11;
            this.t1salbl.Text = "SA";
            // 
            // t1wtlbl
            // 
            this.t1wtlbl.AutoSize = true;
            this.t1wtlbl.Location = new System.Drawing.Point(148, 81);
            this.t1wtlbl.Name = "t1wtlbl";
            this.t1wtlbl.Size = new System.Drawing.Size(41, 13);
            this.t1wtlbl.TabIndex = 10;
            this.t1wtlbl.Text = "Weight";
            // 
            // t1gllbl
            // 
            this.t1gllbl.AutoSize = true;
            this.t1gllbl.ForeColor = System.Drawing.Color.Blue;
            this.t1gllbl.Location = new System.Drawing.Point(92, 81);
            this.t1gllbl.Name = "t1gllbl";
            this.t1gllbl.Size = new System.Drawing.Size(49, 13);
            this.t1gllbl.TabIndex = 9;
            this.t1gllbl.Text = "GL Class";
            // 
            // t1matlbl
            // 
            this.t1matlbl.AutoSize = true;
            this.t1matlbl.ForeColor = System.Drawing.Color.Blue;
            this.t1matlbl.Location = new System.Drawing.Point(36, 81);
            this.t1matlbl.Name = "t1matlbl";
            this.t1matlbl.Size = new System.Drawing.Size(44, 13);
            this.t1matlbl.TabIndex = 8;
            this.t1matlbl.Text = "Material";
            // 
            // t1sa
            // 
            this.t1sa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1sa.Location = new System.Drawing.Point(198, 97);
            this.t1sa.Name = "t1sa";
            this.t1sa.Size = new System.Drawing.Size(47, 20);
            this.t1sa.TabIndex = 5;
            // 
            // t1wt
            // 
            this.t1wt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1wt.Location = new System.Drawing.Point(145, 97);
            this.t1wt.Name = "t1wt";
            this.t1wt.Size = new System.Drawing.Size(47, 20);
            this.t1wt.TabIndex = 4;
            // 
            // t1gl
            // 
            this.t1gl.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1gl.Location = new System.Drawing.Point(92, 97);
            this.t1gl.Name = "t1gl";
            this.t1gl.Size = new System.Drawing.Size(47, 20);
            this.t1gl.TabIndex = 3;
            // 
            // t1mat
            // 
            this.t1mat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1mat.Location = new System.Drawing.Point(39, 97);
            this.t1mat.Name = "t1mat";
            this.t1mat.Size = new System.Drawing.Size(47, 20);
            this.t1mat.TabIndex = 2;
            // 
            // t1desclbl
            // 
            this.t1desclbl.AutoSize = true;
            this.t1desclbl.Location = new System.Drawing.Point(392, 12);
            this.t1desclbl.Name = "t1desclbl";
            this.t1desclbl.Size = new System.Drawing.Size(60, 13);
            this.t1desclbl.TabIndex = 3;
            this.t1desclbl.Text = "Description";
            // 
            // t1pcodelbl
            // 
            this.t1pcodelbl.AutoSize = true;
            this.t1pcodelbl.Location = new System.Drawing.Point(36, 12);
            this.t1pcodelbl.Name = "t1pcodelbl";
            this.t1pcodelbl.Size = new System.Drawing.Size(50, 13);
            this.t1pcodelbl.TabIndex = 2;
            this.t1pcodelbl.Text = "Partcode";
            // 
            // t1desc
            // 
            this.t1desc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1desc.Location = new System.Drawing.Point(395, 37);
            this.t1desc.Name = "t1desc";
            this.t1desc.Size = new System.Drawing.Size(278, 20);
            this.t1desc.TabIndex = 1;
            // 
            // t1pcode
            // 
            this.t1pcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1pcode.Location = new System.Drawing.Point(40, 37);
            this.t1pcode.Name = "t1pcode";
            this.t1pcode.Size = new System.Drawing.Size(278, 20);
            this.t1pcode.TabIndex = 0;
            this.t1pcode.TextChanged += new System.EventHandler(this.t1pcode_TextChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Transparent;
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.t2cleardata);
            this.tabPage2.Controls.Add(this.t2copy);
            this.tabPage2.Controls.Add(this.t2reset);
            this.tabPage2.Controls.Add(this.t2undoadd);
            this.tabPage2.Controls.Add(this.t2undosort);
            this.tabPage2.Controls.Add(this.t2addclear);
            this.tabPage2.Controls.Add(this.t2add);
            this.tabPage2.Controls.Add(this.t2convertlbl);
            this.tabPage2.Controls.Add(this.t2template);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.t2salbl);
            this.tabPage2.Controls.Add(this.t2wtlbl);
            this.tabPage2.Controls.Add(this.t2gllbl);
            this.tabPage2.Controls.Add(this.t2matlbl);
            this.tabPage2.Controls.Add(this.t2sa);
            this.tabPage2.Controls.Add(this.t2wt);
            this.tabPage2.Controls.Add(this.t2gl);
            this.tabPage2.Controls.Add(this.t2mat);
            this.tabPage2.Controls.Add(this.t2desclbl);
            this.tabPage2.Controls.Add(this.t2pcodelbl);
            this.tabPage2.Controls.Add(this.t2desc);
            this.tabPage2.Controls.Add(this.t2pcode);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1171, 685);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Supports";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(800, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(369, 184);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // t2cleardata
            // 
            this.t2cleardata.Location = new System.Drawing.Point(259, 186);
            this.t2cleardata.Name = "t2cleardata";
            this.t2cleardata.Size = new System.Drawing.Size(102, 28);
            this.t2cleardata.TabIndex = 21;
            this.t2cleardata.Text = "Clear Data";
            this.t2cleardata.UseVisualStyleBackColor = true;
            this.t2cleardata.Click += new System.EventHandler(this.t2cleardata_Click);
            // 
            // t2copy
            // 
            this.t2copy.Location = new System.Drawing.Point(367, 186);
            this.t2copy.Name = "t2copy";
            this.t2copy.Size = new System.Drawing.Size(102, 28);
            this.t2copy.TabIndex = 20;
            this.t2copy.Text = "Copy";
            this.t2copy.UseVisualStyleBackColor = true;
            this.t2copy.Click += new System.EventHandler(this.t2copy_Click);
            // 
            // t2reset
            // 
            this.t2reset.Location = new System.Drawing.Point(651, 89);
            this.t2reset.Name = "t2reset";
            this.t2reset.Size = new System.Drawing.Size(102, 28);
            this.t2reset.TabIndex = 19;
            this.t2reset.Text = "Reset Fields";
            this.t2reset.UseVisualStyleBackColor = true;
            this.t2reset.Click += new System.EventHandler(this.t2reset_Click_1);
            // 
            // t2undoadd
            // 
            this.t2undoadd.Location = new System.Drawing.Point(151, 186);
            this.t2undoadd.Name = "t2undoadd";
            this.t2undoadd.Size = new System.Drawing.Size(102, 28);
            this.t2undoadd.TabIndex = 18;
            this.t2undoadd.Text = "Undo Add";
            this.t2undoadd.UseVisualStyleBackColor = true;
            this.t2undoadd.Click += new System.EventHandler(this.t2undoadd_Click);
            // 
            // t2undosort
            // 
            this.t2undosort.Location = new System.Drawing.Point(151, 138);
            this.t2undosort.Name = "t2undosort";
            this.t2undosort.Size = new System.Drawing.Size(102, 28);
            this.t2undosort.TabIndex = 17;
            this.t2undosort.Text = "Undo Sort";
            this.t2undosort.UseVisualStyleBackColor = true;
            this.t2undosort.Click += new System.EventHandler(this.t2undosort_Click);
            // 
            // t2addclear
            // 
            this.t2addclear.Location = new System.Drawing.Point(39, 186);
            this.t2addclear.Name = "t2addclear";
            this.t2addclear.Size = new System.Drawing.Size(102, 28);
            this.t2addclear.TabIndex = 16;
            this.t2addclear.Text = "Add_Clear";
            this.t2addclear.UseVisualStyleBackColor = true;
            this.t2addclear.Click += new System.EventHandler(this.t2addclear_Click);
            // 
            // t2add
            // 
            this.t2add.Location = new System.Drawing.Point(38, 138);
            this.t2add.Name = "t2add";
            this.t2add.Size = new System.Drawing.Size(102, 28);
            this.t2add.TabIndex = 15;
            this.t2add.Text = "Add";
            this.t2add.UseVisualStyleBackColor = true;
            this.t2add.Click += new System.EventHandler(this.t2add_Click);
            // 
            // t2convertlbl
            // 
            this.t2convertlbl.AutoSize = true;
            this.t2convertlbl.ForeColor = System.Drawing.Color.Blue;
            this.t2convertlbl.Location = new System.Drawing.Point(345, 37);
            this.t2convertlbl.Name = "t2convertlbl";
            this.t2convertlbl.Size = new System.Drawing.Size(19, 13);
            this.t2convertlbl.TabIndex = 14;
            this.t2convertlbl.Text = "<--";
            this.t2convertlbl.Click += new System.EventHandler(this.t2convertlbl_Click);
            // 
            // t2template
            // 
            this.t2template.FormattingEnabled = true;
            this.t2template.Location = new System.Drawing.Point(395, 96);
            this.t2template.Name = "t2template";
            this.t2template.Size = new System.Drawing.Size(146, 21);
            this.t2template.TabIndex = 13;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.t2Action,
            this.t2ItemorBranch,
            this.t2branchplant,
            this.t2shortid,
            this.t2itemnumber,
            this.t2thirditemnumber,
            this.t2descriptionone,
            this.t2descriptiontwo,
            this.t2searchtext,
            this.t2comm,
            this.t2subcomm,
            this.t2sizeone,
            this.t2sizetwo,
            this.t2sched,
            this.t2ratgec,
            this.t2specgrade,
            this.t2laborgrp,
            this.t2mtlgrp,
            this.t2pbcodeone,
            this.t2pbcodetwo,
            this.t2pbcodethree,
            this.t2uom,
            this.t2wtum,
            this.t2voluom,
            this.t2classcode,
            this.t2lotproctype,
            this.t2countryreqd,
            this.t2stockingtype,
            this.t2lnty,
            this.t2shelfdays,
            this.t2weightprice,
            this.t2surfacearea,
            this.t2templateid,
            this.t2projmfgreqd});
            this.dataGridView2.Location = new System.Drawing.Point(8, 237);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1162, 440);
            this.dataGridView2.TabIndex = 12;
            // 
            // t2Action
            // 
            this.t2Action.HeaderText = "Action";
            this.t2Action.Name = "t2Action";
            // 
            // t2ItemorBranch
            // 
            this.t2ItemorBranch.HeaderText = "Item or Branch";
            this.t2ItemorBranch.Name = "t2ItemorBranch";
            // 
            // t2branchplant
            // 
            this.t2branchplant.HeaderText = "Branch Plant";
            this.t2branchplant.Name = "t2branchplant";
            // 
            // t2shortid
            // 
            this.t2shortid.HeaderText = "Short ID";
            this.t2shortid.Name = "t2shortid";
            // 
            // t2itemnumber
            // 
            this.t2itemnumber.HeaderText = "Item Number";
            this.t2itemnumber.Name = "t2itemnumber";
            // 
            // t2thirditemnumber
            // 
            this.t2thirditemnumber.HeaderText = "3rd Item Number";
            this.t2thirditemnumber.Name = "t2thirditemnumber";
            // 
            // t2descriptionone
            // 
            this.t2descriptionone.HeaderText = "Description 1";
            this.t2descriptionone.Name = "t2descriptionone";
            // 
            // t2descriptiontwo
            // 
            this.t2descriptiontwo.HeaderText = "Description 2";
            this.t2descriptiontwo.Name = "t2descriptiontwo";
            // 
            // t2searchtext
            // 
            this.t2searchtext.HeaderText = "Search Text";
            this.t2searchtext.Name = "t2searchtext";
            // 
            // t2comm
            // 
            this.t2comm.HeaderText = "Comm";
            this.t2comm.Name = "t2comm";
            // 
            // t2subcomm
            // 
            this.t2subcomm.HeaderText = "Sub Comm";
            this.t2subcomm.Name = "t2subcomm";
            // 
            // t2sizeone
            // 
            this.t2sizeone.HeaderText = "Size 1";
            this.t2sizeone.Name = "t2sizeone";
            // 
            // t2sizetwo
            // 
            this.t2sizetwo.HeaderText = "Size 2";
            this.t2sizetwo.Name = "t2sizetwo";
            // 
            // t2sched
            // 
            this.t2sched.HeaderText = "Sch";
            this.t2sched.Name = "t2sched";
            // 
            // t2ratgec
            // 
            this.t2ratgec.HeaderText = "Rating";
            this.t2ratgec.Name = "t2ratgec";
            // 
            // t2specgrade
            // 
            this.t2specgrade.HeaderText = "Spec Grade";
            this.t2specgrade.Name = "t2specgrade";
            // 
            // t2laborgrp
            // 
            this.t2laborgrp.HeaderText = "Labor Grp";
            this.t2laborgrp.Name = "t2laborgrp";
            // 
            // t2mtlgrp
            // 
            this.t2mtlgrp.HeaderText = "Mtl Grp";
            this.t2mtlgrp.Name = "t2mtlgrp";
            // 
            // t2pbcodeone
            // 
            this.t2pbcodeone.HeaderText = "P/B Code1";
            this.t2pbcodeone.Name = "t2pbcodeone";
            // 
            // t2pbcodetwo
            // 
            this.t2pbcodetwo.HeaderText = "P/B Code2";
            this.t2pbcodetwo.Name = "t2pbcodetwo";
            // 
            // t2pbcodethree
            // 
            this.t2pbcodethree.HeaderText = "P/B Code3";
            this.t2pbcodethree.Name = "t2pbcodethree";
            // 
            // t2uom
            // 
            this.t2uom.HeaderText = "Uom";
            this.t2uom.Name = "t2uom";
            // 
            // t2wtum
            // 
            this.t2wtum.HeaderText = "Wt UM";
            this.t2wtum.Name = "t2wtum";
            // 
            // t2voluom
            // 
            this.t2voluom.HeaderText = "Vol UOM";
            this.t2voluom.Name = "t2voluom";
            // 
            // t2classcode
            // 
            this.t2classcode.HeaderText = "Class Code";
            this.t2classcode.Name = "t2classcode";
            // 
            // t2lotproctype
            // 
            this.t2lotproctype.HeaderText = "Lot Proc Type";
            this.t2lotproctype.Name = "t2lotproctype";
            // 
            // t2countryreqd
            // 
            this.t2countryreqd.HeaderText = "Country Reqd";
            this.t2countryreqd.Name = "t2countryreqd";
            // 
            // t2stockingtype
            // 
            this.t2stockingtype.HeaderText = "Stocking Type";
            this.t2stockingtype.Name = "t2stockingtype";
            // 
            // t2lnty
            // 
            this.t2lnty.HeaderText = "Ln Ty";
            this.t2lnty.Name = "t2lnty";
            // 
            // t2shelfdays
            // 
            this.t2shelfdays.HeaderText = "Shelf Days";
            this.t2shelfdays.Name = "t2shelfdays";
            // 
            // t2weightprice
            // 
            this.t2weightprice.HeaderText = "Weight/Price";
            this.t2weightprice.Name = "t2weightprice";
            // 
            // t2surfacearea
            // 
            this.t2surfacearea.HeaderText = "Surface Area";
            this.t2surfacearea.Name = "t2surfacearea";
            // 
            // t2templateid
            // 
            this.t2templateid.HeaderText = "Template ID";
            this.t2templateid.Name = "t2templateid";
            // 
            // t2projmfgreqd
            // 
            this.t2projmfgreqd.HeaderText = "Prof Mfg Reqd";
            this.t2projmfgreqd.Name = "t2projmfgreqd";
            // 
            // t2salbl
            // 
            this.t2salbl.AutoSize = true;
            this.t2salbl.Location = new System.Drawing.Point(204, 81);
            this.t2salbl.Name = "t2salbl";
            this.t2salbl.Size = new System.Drawing.Size(21, 13);
            this.t2salbl.TabIndex = 11;
            this.t2salbl.Text = "SA";
            // 
            // t2wtlbl
            // 
            this.t2wtlbl.AutoSize = true;
            this.t2wtlbl.Location = new System.Drawing.Point(148, 81);
            this.t2wtlbl.Name = "t2wtlbl";
            this.t2wtlbl.Size = new System.Drawing.Size(41, 13);
            this.t2wtlbl.TabIndex = 10;
            this.t2wtlbl.Text = "Weight";
            // 
            // t2gllbl
            // 
            this.t2gllbl.AutoSize = true;
            this.t2gllbl.ForeColor = System.Drawing.Color.Blue;
            this.t2gllbl.Location = new System.Drawing.Point(92, 81);
            this.t2gllbl.Name = "t2gllbl";
            this.t2gllbl.Size = new System.Drawing.Size(49, 13);
            this.t2gllbl.TabIndex = 9;
            this.t2gllbl.Text = "GL Class";
            // 
            // t2matlbl
            // 
            this.t2matlbl.AutoSize = true;
            this.t2matlbl.ForeColor = System.Drawing.Color.Blue;
            this.t2matlbl.Location = new System.Drawing.Point(36, 81);
            this.t2matlbl.Name = "t2matlbl";
            this.t2matlbl.Size = new System.Drawing.Size(44, 13);
            this.t2matlbl.TabIndex = 8;
            this.t2matlbl.Text = "Material";
            // 
            // t2sa
            // 
            this.t2sa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2sa.Location = new System.Drawing.Point(198, 97);
            this.t2sa.Name = "t2sa";
            this.t2sa.Size = new System.Drawing.Size(47, 20);
            this.t2sa.TabIndex = 5;
            // 
            // t2wt
            // 
            this.t2wt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2wt.Location = new System.Drawing.Point(145, 97);
            this.t2wt.Name = "t2wt";
            this.t2wt.Size = new System.Drawing.Size(47, 20);
            this.t2wt.TabIndex = 4;
            // 
            // t2gl
            // 
            this.t2gl.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2gl.Location = new System.Drawing.Point(92, 97);
            this.t2gl.Name = "t2gl";
            this.t2gl.Size = new System.Drawing.Size(47, 20);
            this.t2gl.TabIndex = 3;
            // 
            // t2mat
            // 
            this.t2mat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2mat.Location = new System.Drawing.Point(39, 97);
            this.t2mat.Name = "t2mat";
            this.t2mat.Size = new System.Drawing.Size(47, 20);
            this.t2mat.TabIndex = 2;
            this.t2mat.TextChanged += new System.EventHandler(this.t2mat_TextChanged_1);
            // 
            // t2desclbl
            // 
            this.t2desclbl.AutoSize = true;
            this.t2desclbl.Location = new System.Drawing.Point(392, 12);
            this.t2desclbl.Name = "t2desclbl";
            this.t2desclbl.Size = new System.Drawing.Size(60, 13);
            this.t2desclbl.TabIndex = 3;
            this.t2desclbl.Text = "Description";
            // 
            // t2pcodelbl
            // 
            this.t2pcodelbl.AutoSize = true;
            this.t2pcodelbl.Location = new System.Drawing.Point(36, 12);
            this.t2pcodelbl.Name = "t2pcodelbl";
            this.t2pcodelbl.Size = new System.Drawing.Size(50, 13);
            this.t2pcodelbl.TabIndex = 2;
            this.t2pcodelbl.Text = "Partcode";
            // 
            // t2desc
            // 
            this.t2desc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2desc.Location = new System.Drawing.Point(395, 37);
            this.t2desc.Name = "t2desc";
            this.t2desc.Size = new System.Drawing.Size(278, 20);
            this.t2desc.TabIndex = 1;
            this.t2desc.TextChanged += new System.EventHandler(this.t2desc_TextChanged_1);
            // 
            // t2pcode
            // 
            this.t2pcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2pcode.Location = new System.Drawing.Point(40, 37);
            this.t2pcode.Name = "t2pcode";
            this.t2pcode.Size = new System.Drawing.Size(278, 20);
            this.t2pcode.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 711);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Item Upload Tool";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label t1desclbl;
        private System.Windows.Forms.Label t1pcodelbl;
        private System.Windows.Forms.TextBox t1desc;
        private System.Windows.Forms.TextBox t1pcode;
        private System.Windows.Forms.Label t1salbl;
        private System.Windows.Forms.Label t1wtlbl;
        private System.Windows.Forms.Label t1gllbl;
        private System.Windows.Forms.Label t1matlbl;
        private System.Windows.Forms.TextBox t1sa;
        private System.Windows.Forms.TextBox t1wt;
        private System.Windows.Forms.TextBox t1gl;
        private System.Windows.Forms.TextBox t1mat;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Action;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemorBranch;
        private System.Windows.Forms.DataGridViewTextBoxColumn branchplant;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortid;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn thirditemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionone;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptiontwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn searchtext;
        private System.Windows.Forms.DataGridViewTextBoxColumn comm;
        private System.Windows.Forms.DataGridViewTextBoxColumn subcomm;
        private System.Windows.Forms.DataGridViewTextBoxColumn sizeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn sizetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn sched;
        private System.Windows.Forms.DataGridViewTextBoxColumn ratgec;
        private System.Windows.Forms.DataGridViewTextBoxColumn specgrade;
        private System.Windows.Forms.DataGridViewTextBoxColumn laborgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn mtlgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn pbcodeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn pbcodetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn pbcodethree;
        private System.Windows.Forms.DataGridViewTextBoxColumn uom;
        private System.Windows.Forms.DataGridViewTextBoxColumn wtum;
        private System.Windows.Forms.DataGridViewTextBoxColumn voluom;
        private System.Windows.Forms.DataGridViewTextBoxColumn classcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn lotproctype;
        private System.Windows.Forms.DataGridViewTextBoxColumn countryreqd;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockingtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnty;
        private System.Windows.Forms.DataGridViewTextBoxColumn shelfdays;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn surfacearea;
        private System.Windows.Forms.DataGridViewTextBoxColumn templateid;
        private System.Windows.Forms.DataGridViewTextBoxColumn projmfgreqd;
        private System.Windows.Forms.ComboBox t1template;
        private System.Windows.Forms.Label t2desclbl;
        private System.Windows.Forms.Label t2pcodelbl;
        private System.Windows.Forms.TextBox t2desc;
        private System.Windows.Forms.TextBox t2pcode;
        private System.Windows.Forms.Label t2salbl;
        private System.Windows.Forms.Label t2wtlbl;
        private System.Windows.Forms.Label t2gllbl;
        private System.Windows.Forms.Label t2matlbl;
        private System.Windows.Forms.TextBox t2sa;
        private System.Windows.Forms.TextBox t2wt;
        private System.Windows.Forms.TextBox t2gl;
        private System.Windows.Forms.TextBox t2mat;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2Action;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2ItemorBranch;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2branchplant;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2shortid;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2itemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2thirditemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2descriptionone;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2descriptiontwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2searchtext;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2comm;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2subcomm;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2sizeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2sizetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2sched;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2ratgec;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2specgrade;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2laborgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2mtlgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2pbcodeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2pbcodetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2pbcodethree;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2uom;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2wtum;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2voluom;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2classcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2lotproctype;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2countryreqd;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2stockingtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2lnty;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2shelfdays;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2weightprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2surfacearea;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2templateid;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2projmfgreqd;
        private System.Windows.Forms.ComboBox t2template;
        private System.Windows.Forms.Label t2convertlbl;
        private System.Windows.Forms.Button t1reset;
        private System.Windows.Forms.Button t1copy;
        private System.Windows.Forms.Button t1undoadd;
        private System.Windows.Forms.Button t1addclear;
        private System.Windows.Forms.Button t1undosort;
        private System.Windows.Forms.Button t1add;
        private System.Windows.Forms.Button t2add;
        private System.Windows.Forms.Button t2copy;
        private System.Windows.Forms.Button t2reset;
        private System.Windows.Forms.Button t2undoadd;
        private System.Windows.Forms.Button t2undosort;
        private System.Windows.Forms.Button t2addclear;
        private System.Windows.Forms.Button t1cleardata;
        private System.Windows.Forms.Button t2cleardata;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

