﻿namespace ItemUploadTool
{


    partial class PD_EDWDataSet
    {
        partial class JDEItemMasterDataTable
        {
        }
    }
}

namespace ItemUploadTool.PD_EDWDataSetTableAdapters {
    
    
    public partial class JDEItemMasterTableAdapter {
    }
}
