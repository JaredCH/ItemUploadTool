﻿namespace ItemUploadTool
{


    partial class PD_EDWDataSet2
    {
        partial class MTODashboardDataTable
        {
        }
    }
}
