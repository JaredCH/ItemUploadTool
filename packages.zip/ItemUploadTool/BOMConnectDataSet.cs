﻿namespace ItemUploadTool
{


    partial class BOMConnectDataSet
    {
    }
}

namespace ItemUploadTool.BOMConnectDataSetTableAdapters
{
    partial class MTODashboardTableAdapter
    {
    }

    public partial class spoolsTableAdapter {
    }
}
