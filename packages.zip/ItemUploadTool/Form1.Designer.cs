﻿namespace ItemUploadTool
{
    partial class Form1
    {

   
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabcontrol = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.t1TagItemCB = new System.Windows.Forms.CheckBox();
            this.t1imtable = new System.Windows.Forms.DataGridView();
            this.t1desccheckbox = new System.Windows.Forms.CheckBox();
            this.t1missingitems = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.t1importcm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.importFromClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importFromClipboardSIDMGLWtSAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.t1matlabel = new System.Windows.Forms.Label();
            this.tboxmat = new System.Windows.Forms.TextBox();
            this.t1ratinglabel = new System.Windows.Forms.Label();
            this.tboxrating = new System.Windows.Forms.TextBox();
            this.t1schlabel = new System.Windows.Forms.Label();
            this.tboxsch = new System.Windows.Forms.TextBox();
            this.t1size2label = new System.Windows.Forms.Label();
            this.tboxsize2 = new System.Windows.Forms.TextBox();
            this.t1size1label = new System.Windows.Forms.Label();
            this.tboxsize1 = new System.Windows.Forms.TextBox();
            this.t1subcomlabel = new System.Windows.Forms.Label();
            this.tboxsubcom = new System.Windows.Forms.TextBox();
            this.t1comlabel = new System.Windows.Forms.Label();
            this.tboxcom = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.t1cleardata = new System.Windows.Forms.Button();
            this.t1reset = new System.Windows.Forms.Button();
            this.t1copy = new System.Windows.Forms.Button();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.t1undoadd = new System.Windows.Forms.Button();
            this.t1addclear = new System.Windows.Forms.Button();
            this.t1addclearcm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addAsCorrection04ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.t1undosort = new System.Windows.Forms.Button();
            this.t1add = new System.Windows.Forms.Button();
            this.t1addcm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addAsCorrection04ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.t1template = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Action = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemorBranch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.branchplant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shortid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.thirditemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptiontwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.searchtext = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subcomm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sizeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sizetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sched = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ratgec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specgrade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laborgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mtlgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbcodeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbcodetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pbcodethree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wtum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.voluom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lotproctype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countryreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockingtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lnty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shelfdays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surfacearea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.templateid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.projmfgreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t1salbl = new System.Windows.Forms.Label();
            this.t1wtlbl = new System.Windows.Forms.Label();
            this.t1gllbl = new System.Windows.Forms.Label();
            this.t1matlbl = new System.Windows.Forms.Label();
            this.t1sa = new System.Windows.Forms.TextBox();
            this.t1wt = new System.Windows.Forms.TextBox();
            this.t1gl = new System.Windows.Forms.TextBox();
            this.t1mat = new System.Windows.Forms.TextBox();
            this.t1desclbl = new System.Windows.Forms.Label();
            this.t1pcodelbl = new System.Windows.Forms.Label();
            this.t1desc = new System.Windows.Forms.TextBox();
            this.t1pcode = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.t2reflabel = new System.Windows.Forms.Label();
            this.t2reftextbox = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.t2reqbuilder1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2reqbuilder2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2reqbuilder3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2reqbuilder4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2reqbuilder5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2jobnumberlabel = new System.Windows.Forms.Label();
            this.t2qtylabel = new System.Windows.Forms.Label();
            this.t2qtytextbox = new System.Windows.Forms.TextBox();
            this.t2jobnumbertextbox = new System.Windows.Forms.TextBox();
            this.t2reqcheckbox = new System.Windows.Forms.CheckBox();
            this.t2listfromclip = new System.Windows.Forms.ComboBox();
            this.t2importfromclip = new System.Windows.Forms.Button();
            this.t2importsupt = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.importFromClipboardDescMatGLWtSAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importFromFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.t2cleardata = new System.Windows.Forms.Button();
            this.t2copy = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyAsReqToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.t2reset = new System.Windows.Forms.Button();
            this.t2undoadd = new System.Windows.Forms.Button();
            this.t2undosort = new System.Windows.Forms.Button();
            this.t2addclear = new System.Windows.Forms.Button();
            this.t2addclearcm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.t2add = new System.Windows.Forms.Button();
            this.t2addcm = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.t2convertlbl = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.t2Action = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2ItemorBranch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2branchplant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2shortid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2itemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2thirditemnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2descriptionone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2descriptiontwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2searchtext = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2comm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2subcomm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2sizeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2sizetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2sched = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2ratgec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2specgrade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2laborgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2mtlgrp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2pbcodeone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2pbcodetwo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2pbcodethree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2uom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2wtum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2voluom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2classcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2lotproctype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2countryreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2stockingtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2lnty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2shelfdays = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2weightprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2surfacearea = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2templateid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2projmfgreqd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t2salbl = new System.Windows.Forms.Label();
            this.t2wtlbl = new System.Windows.Forms.Label();
            this.t2gllbl = new System.Windows.Forms.Label();
            this.t2matlbl = new System.Windows.Forms.Label();
            this.t2sa = new System.Windows.Forms.TextBox();
            this.t2wt = new System.Windows.Forms.TextBox();
            this.t2gl = new System.Windows.Forms.TextBox();
            this.t2mat = new System.Windows.Forms.TextBox();
            this.t2desclbl = new System.Windows.Forms.Label();
            this.t2pcodelbl = new System.Windows.Forms.Label();
            this.t2desc = new System.Windows.Forms.TextBox();
            this.t2pcode = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.ChkDesc = new System.Windows.Forms.Button();
            this.t3breakout = new System.Windows.Forms.DataGridView();
            this.t3subcom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t3size1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t3size2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t3sch = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t3rating = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t3sgc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Desc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Partcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t3pasteandbreakout = new System.Windows.Forms.Button();
            this.t3importfibreakout = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.t3clear = new System.Windows.Forms.Button();
            this.t3selectallandcopy = new System.Windows.Forms.Button();
            this.t3copyjdedesc = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.t3pasteandcheckbutton = new System.Windows.Forms.Button();
            this.t3importfromimport = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.t4rb2 = new System.Windows.Forms.RadioButton();
            this.t4rb1 = new System.Windows.Forms.RadioButton();
            this.t4ClearData = new System.Windows.Forms.Button();
            this.t4ClearList = new System.Windows.Forms.Button();
            this.t4AddToList = new System.Windows.Forms.Button();
            this.t4BarcodeBomList = new System.Windows.Forms.DataGridView();
            this.bcodes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4LoadBomBarcodes = new System.Windows.Forms.Button();
            this.t4refdwgtb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.T4LoadBom = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.t4dgv = new System.Windows.Forms.DataGridView();
            this.t4trans = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4iso = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SPEC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4itemcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4clientdesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4pcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4desc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.t4spooltb = new System.Windows.Forms.TextBox();
            this.t4jobtb = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.mtoDataSet1 = new ItemUploadTool.MTODataSet();
            this.pD_EDWDataSet1 = new ItemUploadTool.PD_EDWDataSet1();
            this.pD_EDWDataSet11 = new ItemUploadTool.PD_EDWDataSet1();
            this.pD_EDWDataSet12 = new ItemUploadTool.PD_EDWDataSet1();
            this.mtoDataSet2 = new ItemUploadTool.MTODataSet();
            this.itemCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pD_EDWDataSet = new ItemUploadTool.PD_EDWDataSet();
            this.jDEItemMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.specTableAdapter = new ItemUploadTool.PD_EDWDataSetTableAdapters.SpecTableAdapter();
            this.jDEItemMasterTableAdapter = new ItemUploadTool.PD_EDWDataSetTableAdapters.JDEItemMasterTableAdapter();
            this.pDEDWDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabcontrol.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t1imtable)).BeginInit();
            this.t1importcm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.t1addclearcm.SuspendLayout();
            this.t1addcm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.t2importsupt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.t2addclearcm.SuspendLayout();
            this.t2addcm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t3breakout)).BeginInit();
            this.t3importfibreakout.SuspendLayout();
            this.t3copyjdedesc.SuspendLayout();
            this.t3importfromimport.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t4BarcodeBomList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.t4dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mtoDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mtoDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.specBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jDEItemMasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDEDWDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabcontrol
            // 
            this.tabcontrol.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabcontrol.Controls.Add(this.tabPage1);
            this.tabcontrol.Controls.Add(this.tabPage2);
            this.tabcontrol.Controls.Add(this.tabPage3);
            this.tabcontrol.Controls.Add(this.tabPage4);
            this.tabcontrol.Location = new System.Drawing.Point(-1, 1);
            this.tabcontrol.Name = "tabcontrol";
            this.tabcontrol.SelectedIndex = 0;
            this.tabcontrol.Size = new System.Drawing.Size(1191, 711);
            this.tabcontrol.TabIndex = 21;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.t1TagItemCB);
            this.tabPage1.Controls.Add(this.t1imtable);
            this.tabPage1.Controls.Add(this.t1desccheckbox);
            this.tabPage1.Controls.Add(this.t1missingitems);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.t1matlabel);
            this.tabPage1.Controls.Add(this.tboxmat);
            this.tabPage1.Controls.Add(this.t1ratinglabel);
            this.tabPage1.Controls.Add(this.tboxrating);
            this.tabPage1.Controls.Add(this.t1schlabel);
            this.tabPage1.Controls.Add(this.tboxsch);
            this.tabPage1.Controls.Add(this.t1size2label);
            this.tabPage1.Controls.Add(this.tboxsize2);
            this.tabPage1.Controls.Add(this.t1size1label);
            this.tabPage1.Controls.Add(this.tboxsize1);
            this.tabPage1.Controls.Add(this.t1subcomlabel);
            this.tabPage1.Controls.Add(this.tboxsubcom);
            this.tabPage1.Controls.Add(this.t1comlabel);
            this.tabPage1.Controls.Add(this.tboxcom);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.t1cleardata);
            this.tabPage1.Controls.Add(this.t1reset);
            this.tabPage1.Controls.Add(this.t1copy);
            this.tabPage1.Controls.Add(this.t1undoadd);
            this.tabPage1.Controls.Add(this.t1addclear);
            this.tabPage1.Controls.Add(this.t1undosort);
            this.tabPage1.Controls.Add(this.t1add);
            this.tabPage1.Controls.Add(this.t1template);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.t1salbl);
            this.tabPage1.Controls.Add(this.t1wtlbl);
            this.tabPage1.Controls.Add(this.t1gllbl);
            this.tabPage1.Controls.Add(this.t1matlbl);
            this.tabPage1.Controls.Add(this.t1sa);
            this.tabPage1.Controls.Add(this.t1wt);
            this.tabPage1.Controls.Add(this.t1gl);
            this.tabPage1.Controls.Add(this.t1mat);
            this.tabPage1.Controls.Add(this.t1desclbl);
            this.tabPage1.Controls.Add(this.t1pcodelbl);
            this.tabPage1.Controls.Add(this.t1desc);
            this.tabPage1.Controls.Add(this.t1pcode);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1183, 685);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Fittings";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // t1TagItemCB
            // 
            this.t1TagItemCB.AutoSize = true;
            this.t1TagItemCB.Location = new System.Drawing.Point(560, 156);
            this.t1TagItemCB.Name = "t1TagItemCB";
            this.t1TagItemCB.Size = new System.Drawing.Size(99, 17);
            this.t1TagItemCB.TabIndex = 57;
            this.t1TagItemCB.Text = "Item needs tag.";
            this.t1TagItemCB.UseVisualStyleBackColor = true;
            this.t1TagItemCB.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // t1imtable
            // 
            this.t1imtable.AllowUserToAddRows = false;
            this.t1imtable.AllowUserToDeleteRows = false;
            this.t1imtable.AutoGenerateColumns = false;
            this.t1imtable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.t1imtable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.t1imtable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemCodeDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn});
            this.t1imtable.DataSource = this.specBindingSource;
            this.t1imtable.Location = new System.Drawing.Point(700, -1);
            this.t1imtable.Name = "t1imtable";
            this.t1imtable.ReadOnly = true;
            this.t1imtable.RowHeadersVisible = false;
            this.t1imtable.Size = new System.Drawing.Size(149, 38);
            this.t1imtable.TabIndex = 56;
            this.t1imtable.Visible = false;
            this.t1imtable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.t1imtable_CellContentClick);
            // 
            // t1desccheckbox
            // 
            this.t1desccheckbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.t1desccheckbox.AutoSize = true;
            this.t1desccheckbox.Location = new System.Drawing.Point(1119, 208);
            this.t1desccheckbox.Name = "t1desccheckbox";
            this.t1desccheckbox.Size = new System.Drawing.Size(51, 17);
            this.t1desccheckbox.TabIndex = 55;
            this.t1desccheckbox.Text = "Desc";
            this.t1desccheckbox.UseVisualStyleBackColor = true;
            // 
            // t1missingitems
            // 
            this.t1missingitems.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.t1missingitems.DisplayMember = "Value";
            this.t1missingitems.FormattingEnabled = true;
            this.t1missingitems.Location = new System.Drawing.Point(921, 207);
            this.t1missingitems.Name = "t1missingitems";
            this.t1missingitems.Size = new System.Drawing.Size(190, 21);
            this.t1missingitems.TabIndex = 15;
            this.t1missingitems.ValueMember = "Value";
            this.t1missingitems.SelectedIndexChanged += new System.EventHandler(this.t1missingitems_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(166, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 53;
            this.label1.Text = "Status:*";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.ContextMenuStrip = this.t1importcm;
            this.button1.Location = new System.Drawing.Point(812, 201);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 30);
            this.button1.TabIndex = 52;
            this.button1.Text = "Import Missing*";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // t1importcm
            // 
            this.t1importcm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importFromClipboardToolStripMenuItem,
            this.importFromClipboardSIDMGLWtSAToolStripMenuItem});
            this.t1importcm.Name = "contextMenuStrip1";
            this.t1importcm.Size = new System.Drawing.Size(329, 48);
            this.t1importcm.Opening += new System.ComponentModel.CancelEventHandler(this.t1importcm_Opening);
            // 
            // importFromClipboardToolStripMenuItem
            // 
            this.importFromClipboardToolStripMenuItem.Name = "importFromClipboardToolStripMenuItem";
            this.importFromClipboardToolStripMenuItem.Size = new System.Drawing.Size(328, 22);
            this.importFromClipboardToolStripMenuItem.Text = "Import From Clipboard";
            this.importFromClipboardToolStripMenuItem.Click += new System.EventHandler(this.importFromClipboardToolStripMenuItem_Click);
            // 
            // importFromClipboardSIDMGLWtSAToolStripMenuItem
            // 
            this.importFromClipboardSIDMGLWtSAToolStripMenuItem.Name = "importFromClipboardSIDMGLWtSAToolStripMenuItem";
            this.importFromClipboardSIDMGLWtSAToolStripMenuItem.Size = new System.Drawing.Size(328, 22);
            this.importFromClipboardSIDMGLWtSAToolStripMenuItem.Text = "Import From Clipboard PC-Desc-Mat-GL-Wt-SA";
            this.importFromClipboardSIDMGLWtSAToolStripMenuItem.Click += new System.EventHandler(this.importFromClipboardSIDMGLWtSAToolStripMenuItem_Click);
            // 
            // t1matlabel
            // 
            this.t1matlabel.AutoSize = true;
            this.t1matlabel.Location = new System.Drawing.Point(670, 81);
            this.t1matlabel.Name = "t1matlabel";
            this.t1matlabel.Size = new System.Drawing.Size(25, 13);
            this.t1matlabel.TabIndex = 51;
            this.t1matlabel.Text = "Mat";
            // 
            // tboxmat
            // 
            this.tboxmat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tboxmat.Location = new System.Drawing.Point(664, 97);
            this.tboxmat.Name = "tboxmat";
            this.tboxmat.Size = new System.Drawing.Size(40, 20);
            this.tboxmat.TabIndex = 50;
            this.tboxmat.Tag = "";
            this.tboxmat.TextChanged += new System.EventHandler(this.tboxmat_TextChanged);
            // 
            // t1ratinglabel
            // 
            this.t1ratinglabel.AutoSize = true;
            this.t1ratinglabel.Location = new System.Drawing.Point(617, 81);
            this.t1ratinglabel.Name = "t1ratinglabel";
            this.t1ratinglabel.Size = new System.Drawing.Size(38, 13);
            this.t1ratinglabel.TabIndex = 49;
            this.t1ratinglabel.Text = "Rating";
            // 
            // tboxrating
            // 
            this.tboxrating.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tboxrating.Location = new System.Drawing.Point(615, 97);
            this.tboxrating.Name = "tboxrating";
            this.tboxrating.Size = new System.Drawing.Size(40, 20);
            this.tboxrating.TabIndex = 48;
            // 
            // t1schlabel
            // 
            this.t1schlabel.AutoSize = true;
            this.t1schlabel.Location = new System.Drawing.Point(575, 81);
            this.t1schlabel.Name = "t1schlabel";
            this.t1schlabel.Size = new System.Drawing.Size(26, 13);
            this.t1schlabel.TabIndex = 47;
            this.t1schlabel.Text = "Sch";
            // 
            // tboxsch
            // 
            this.tboxsch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tboxsch.Location = new System.Drawing.Point(569, 97);
            this.tboxsch.Name = "tboxsch";
            this.tboxsch.Size = new System.Drawing.Size(40, 20);
            this.tboxsch.TabIndex = 46;
            // 
            // t1size2label
            // 
            this.t1size2label.AutoSize = true;
            this.t1size2label.Location = new System.Drawing.Point(524, 81);
            this.t1size2label.Name = "t1size2label";
            this.t1size2label.Size = new System.Drawing.Size(36, 13);
            this.t1size2label.TabIndex = 45;
            this.t1size2label.Text = "Size 2";
            // 
            // tboxsize2
            // 
            this.tboxsize2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tboxsize2.Location = new System.Drawing.Point(523, 97);
            this.tboxsize2.Name = "tboxsize2";
            this.tboxsize2.Size = new System.Drawing.Size(40, 20);
            this.tboxsize2.TabIndex = 44;
            // 
            // t1size1label
            // 
            this.t1size1label.AutoSize = true;
            this.t1size1label.Location = new System.Drawing.Point(481, 81);
            this.t1size1label.Name = "t1size1label";
            this.t1size1label.Size = new System.Drawing.Size(36, 13);
            this.t1size1label.TabIndex = 43;
            this.t1size1label.Text = "Size 1";
            // 
            // tboxsize1
            // 
            this.tboxsize1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tboxsize1.Location = new System.Drawing.Point(477, 97);
            this.tboxsize1.Name = "tboxsize1";
            this.tboxsize1.Size = new System.Drawing.Size(40, 20);
            this.tboxsize1.TabIndex = 42;
            this.tboxsize1.TextChanged += new System.EventHandler(this.tboxsize1_TextChanged);
            // 
            // t1subcomlabel
            // 
            this.t1subcomlabel.AutoSize = true;
            this.t1subcomlabel.Location = new System.Drawing.Point(428, 81);
            this.t1subcomlabel.Name = "t1subcomlabel";
            this.t1subcomlabel.Size = new System.Drawing.Size(50, 13);
            this.t1subcomlabel.TabIndex = 41;
            this.t1subcomlabel.Text = "Sub-Com";
            // 
            // tboxsubcom
            // 
            this.tboxsubcom.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tboxsubcom.Location = new System.Drawing.Point(431, 97);
            this.tboxsubcom.Name = "tboxsubcom";
            this.tboxsubcom.Size = new System.Drawing.Size(40, 20);
            this.tboxsubcom.TabIndex = 40;
            this.tboxsubcom.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // t1comlabel
            // 
            this.t1comlabel.AutoSize = true;
            this.t1comlabel.Location = new System.Drawing.Point(392, 81);
            this.t1comlabel.Name = "t1comlabel";
            this.t1comlabel.Size = new System.Drawing.Size(36, 13);
            this.t1comlabel.TabIndex = 39;
            this.t1comlabel.Text = "Comm";
            // 
            // tboxcom
            // 
            this.tboxcom.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tboxcom.Location = new System.Drawing.Point(395, 97);
            this.tboxcom.Name = "tboxcom";
            this.tboxcom.Size = new System.Drawing.Size(30, 20);
            this.tboxcom.TabIndex = 38;
            this.tboxcom.TextChanged += new System.EventHandler(this.tboxcom_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(806, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(369, 184);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // t1cleardata
            // 
            this.t1cleardata.Location = new System.Drawing.Point(220, 186);
            this.t1cleardata.Name = "t1cleardata";
            this.t1cleardata.Size = new System.Drawing.Size(85, 28);
            this.t1cleardata.TabIndex = 20;
            this.t1cleardata.Text = "Clear Data";
            this.t1cleardata.UseVisualStyleBackColor = true;
            this.t1cleardata.Click += new System.EventHandler(this.t1cleardata_Click);
            // 
            // t1reset
            // 
            this.t1reset.Location = new System.Drawing.Point(220, 138);
            this.t1reset.Name = "t1reset";
            this.t1reset.Size = new System.Drawing.Size(85, 28);
            this.t1reset.TabIndex = 19;
            this.t1reset.Text = "Reset Fields";
            this.t1reset.UseVisualStyleBackColor = true;
            this.t1reset.Click += new System.EventHandler(this.t1reset_Click);
            // 
            // t1copy
            // 
            this.t1copy.ContextMenuStrip = this.contextMenuStrip2;
            this.t1copy.Location = new System.Drawing.Point(311, 186);
            this.t1copy.Name = "t1copy";
            this.t1copy.Size = new System.Drawing.Size(85, 28);
            this.t1copy.TabIndex = 18;
            this.t1copy.Text = "Copy*";
            this.t1copy.UseVisualStyleBackColor = true;
            this.t1copy.Click += new System.EventHandler(this.t1copy_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5});
            this.contextMenuStrip2.Name = "contextMenuStrip1";
            this.contextMenuStrip2.Size = new System.Drawing.Size(140, 26);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(139, 22);
            this.toolStripMenuItem5.Text = "Copy as Req";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // t1undoadd
            // 
            this.t1undoadd.Location = new System.Drawing.Point(129, 186);
            this.t1undoadd.Name = "t1undoadd";
            this.t1undoadd.Size = new System.Drawing.Size(85, 28);
            this.t1undoadd.TabIndex = 17;
            this.t1undoadd.Text = "Undo Add";
            this.t1undoadd.UseVisualStyleBackColor = true;
            this.t1undoadd.Click += new System.EventHandler(this.t1undoadd_Click);
            // 
            // t1addclear
            // 
            this.t1addclear.ContextMenuStrip = this.t1addclearcm;
            this.t1addclear.Location = new System.Drawing.Point(39, 186);
            this.t1addclear.Name = "t1addclear";
            this.t1addclear.Size = new System.Drawing.Size(85, 28);
            this.t1addclear.TabIndex = 16;
            this.t1addclear.Text = "Add_Clear*";
            this.t1addclear.UseVisualStyleBackColor = true;
            this.t1addclear.Click += new System.EventHandler(this.t1addclear_Click);
            // 
            // t1addclearcm
            // 
            this.t1addclearcm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addAsCorrection04ToolStripMenuItem1});
            this.t1addclearcm.Name = "t1addclearcm";
            this.t1addclearcm.Size = new System.Drawing.Size(191, 26);
            // 
            // addAsCorrection04ToolStripMenuItem1
            // 
            this.addAsCorrection04ToolStripMenuItem1.Name = "addAsCorrection04ToolStripMenuItem1";
            this.addAsCorrection04ToolStripMenuItem1.Size = new System.Drawing.Size(190, 22);
            this.addAsCorrection04ToolStripMenuItem1.Text = "Add as correction (04)";
            this.addAsCorrection04ToolStripMenuItem1.Click += new System.EventHandler(this.addAsCorrection04ToolStripMenuItem1_Click);
            // 
            // t1undosort
            // 
            this.t1undosort.Location = new System.Drawing.Point(129, 138);
            this.t1undosort.Name = "t1undosort";
            this.t1undosort.Size = new System.Drawing.Size(85, 28);
            this.t1undosort.TabIndex = 15;
            this.t1undosort.Text = "Undo Sort";
            this.t1undosort.UseVisualStyleBackColor = true;
            this.t1undosort.Click += new System.EventHandler(this.t1undosort_Click);
            // 
            // t1add
            // 
            this.t1add.ContextMenuStrip = this.t1addcm;
            this.t1add.Location = new System.Drawing.Point(38, 138);
            this.t1add.Name = "t1add";
            this.t1add.Size = new System.Drawing.Size(85, 28);
            this.t1add.TabIndex = 14;
            this.t1add.Text = "Add*";
            this.t1add.UseVisualStyleBackColor = true;
            this.t1add.Click += new System.EventHandler(this.t1add_Click);
            // 
            // t1addcm
            // 
            this.t1addcm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addAsCorrection04ToolStripMenuItem});
            this.t1addcm.Name = "contextMenuStrip1";
            this.t1addcm.Size = new System.Drawing.Size(191, 26);
            // 
            // addAsCorrection04ToolStripMenuItem
            // 
            this.addAsCorrection04ToolStripMenuItem.Name = "addAsCorrection04ToolStripMenuItem";
            this.addAsCorrection04ToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.addAsCorrection04ToolStripMenuItem.Text = "Add as correction (04)";
            this.addAsCorrection04ToolStripMenuItem.Click += new System.EventHandler(this.addAsCorrection04ToolStripMenuItem_Click);
            // 
            // t1template
            // 
            this.t1template.FormattingEnabled = true;
            this.t1template.Location = new System.Drawing.Point(558, 123);
            this.t1template.Name = "t1template";
            this.t1template.Size = new System.Drawing.Size(146, 21);
            this.t1template.TabIndex = 13;
            this.t1template.SelectedIndexChanged += new System.EventHandler(this.t1template_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Action,
            this.ItemorBranch,
            this.branchplant,
            this.shortid,
            this.itemnumber,
            this.thirditemnumber,
            this.descriptionone,
            this.descriptiontwo,
            this.searchtext,
            this.comm,
            this.subcomm,
            this.sizeone,
            this.sizetwo,
            this.sched,
            this.ratgec,
            this.specgrade,
            this.laborgrp,
            this.mtlgrp,
            this.pbcodeone,
            this.pbcodetwo,
            this.pbcodethree,
            this.uom,
            this.wtum,
            this.voluom,
            this.classcode,
            this.lotproctype,
            this.countryreqd,
            this.stockingtype,
            this.lnty,
            this.shelfdays,
            this.weightprice,
            this.surfacearea,
            this.templateid,
            this.projmfgreqd});
            this.dataGridView1.Location = new System.Drawing.Point(2, 243);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(1174, 440);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Action
            // 
            this.Action.HeaderText = "Action";
            this.Action.Name = "Action";
            // 
            // ItemorBranch
            // 
            this.ItemorBranch.HeaderText = "Item or Branch";
            this.ItemorBranch.Name = "ItemorBranch";
            // 
            // branchplant
            // 
            this.branchplant.HeaderText = "Branch Plant";
            this.branchplant.Name = "branchplant";
            // 
            // shortid
            // 
            this.shortid.HeaderText = "Short ID";
            this.shortid.Name = "shortid";
            // 
            // itemnumber
            // 
            this.itemnumber.HeaderText = "Item Number";
            this.itemnumber.Name = "itemnumber";
            // 
            // thirditemnumber
            // 
            this.thirditemnumber.HeaderText = "3rd Item Number";
            this.thirditemnumber.Name = "thirditemnumber";
            // 
            // descriptionone
            // 
            this.descriptionone.HeaderText = "Description 1";
            this.descriptionone.Name = "descriptionone";
            // 
            // descriptiontwo
            // 
            this.descriptiontwo.HeaderText = "Description 2";
            this.descriptiontwo.Name = "descriptiontwo";
            // 
            // searchtext
            // 
            this.searchtext.HeaderText = "Search Text";
            this.searchtext.Name = "searchtext";
            // 
            // comm
            // 
            this.comm.HeaderText = "Comm";
            this.comm.Name = "comm";
            // 
            // subcomm
            // 
            this.subcomm.HeaderText = "Sub Comm";
            this.subcomm.Name = "subcomm";
            // 
            // sizeone
            // 
            this.sizeone.HeaderText = "Size 1";
            this.sizeone.Name = "sizeone";
            // 
            // sizetwo
            // 
            this.sizetwo.HeaderText = "Size 2";
            this.sizetwo.Name = "sizetwo";
            // 
            // sched
            // 
            this.sched.HeaderText = "Sch";
            this.sched.Name = "sched";
            // 
            // ratgec
            // 
            this.ratgec.HeaderText = "Rating";
            this.ratgec.Name = "ratgec";
            // 
            // specgrade
            // 
            this.specgrade.HeaderText = "Spec Grade";
            this.specgrade.Name = "specgrade";
            // 
            // laborgrp
            // 
            this.laborgrp.HeaderText = "Labor Grp";
            this.laborgrp.Name = "laborgrp";
            // 
            // mtlgrp
            // 
            this.mtlgrp.HeaderText = "Mtl Grp";
            this.mtlgrp.Name = "mtlgrp";
            // 
            // pbcodeone
            // 
            this.pbcodeone.HeaderText = "P/B Code1";
            this.pbcodeone.Name = "pbcodeone";
            // 
            // pbcodetwo
            // 
            this.pbcodetwo.HeaderText = "P/B Code2";
            this.pbcodetwo.Name = "pbcodetwo";
            // 
            // pbcodethree
            // 
            this.pbcodethree.HeaderText = "P/B Code3";
            this.pbcodethree.Name = "pbcodethree";
            // 
            // uom
            // 
            this.uom.HeaderText = "Uom";
            this.uom.Name = "uom";
            // 
            // wtum
            // 
            this.wtum.HeaderText = "Wt UM";
            this.wtum.Name = "wtum";
            // 
            // voluom
            // 
            this.voluom.HeaderText = "Vol UOM";
            this.voluom.Name = "voluom";
            // 
            // classcode
            // 
            this.classcode.HeaderText = "Class Code";
            this.classcode.Name = "classcode";
            // 
            // lotproctype
            // 
            this.lotproctype.HeaderText = "Lot Proc Type";
            this.lotproctype.Name = "lotproctype";
            // 
            // countryreqd
            // 
            this.countryreqd.HeaderText = "Country Reqd";
            this.countryreqd.Name = "countryreqd";
            // 
            // stockingtype
            // 
            this.stockingtype.HeaderText = "Stocking Type";
            this.stockingtype.Name = "stockingtype";
            // 
            // lnty
            // 
            this.lnty.HeaderText = "Ln Ty";
            this.lnty.Name = "lnty";
            // 
            // shelfdays
            // 
            this.shelfdays.HeaderText = "Shelf Days";
            this.shelfdays.Name = "shelfdays";
            // 
            // weightprice
            // 
            this.weightprice.HeaderText = "Weight/Price";
            this.weightprice.Name = "weightprice";
            // 
            // surfacearea
            // 
            this.surfacearea.HeaderText = "Surface Area";
            this.surfacearea.Name = "surfacearea";
            // 
            // templateid
            // 
            this.templateid.HeaderText = "Template ID";
            this.templateid.Name = "templateid";
            // 
            // projmfgreqd
            // 
            this.projmfgreqd.HeaderText = "Prof Mfg Reqd";
            this.projmfgreqd.Name = "projmfgreqd";
            // 
            // t1salbl
            // 
            this.t1salbl.AutoSize = true;
            this.t1salbl.Location = new System.Drawing.Point(186, 81);
            this.t1salbl.Name = "t1salbl";
            this.t1salbl.Size = new System.Drawing.Size(21, 13);
            this.t1salbl.TabIndex = 11;
            this.t1salbl.Text = "SA";
            // 
            // t1wtlbl
            // 
            this.t1wtlbl.AutoSize = true;
            this.t1wtlbl.Location = new System.Drawing.Point(130, 81);
            this.t1wtlbl.Name = "t1wtlbl";
            this.t1wtlbl.Size = new System.Drawing.Size(41, 13);
            this.t1wtlbl.TabIndex = 10;
            this.t1wtlbl.Text = "Weight";
            // 
            // t1gllbl
            // 
            this.t1gllbl.AutoSize = true;
            this.t1gllbl.ForeColor = System.Drawing.Color.Blue;
            this.t1gllbl.Location = new System.Drawing.Point(82, 81);
            this.t1gllbl.Name = "t1gllbl";
            this.t1gllbl.Size = new System.Drawing.Size(49, 13);
            this.t1gllbl.TabIndex = 9;
            this.t1gllbl.Text = "GL Class";
            this.t1gllbl.Click += new System.EventHandler(this.t1gllbl_Click);
            // 
            // t1matlbl
            // 
            this.t1matlbl.AutoSize = true;
            this.t1matlbl.ForeColor = System.Drawing.Color.Blue;
            this.t1matlbl.Location = new System.Drawing.Point(36, 81);
            this.t1matlbl.Name = "t1matlbl";
            this.t1matlbl.Size = new System.Drawing.Size(44, 13);
            this.t1matlbl.TabIndex = 8;
            this.t1matlbl.Text = "Material";
            this.t1matlbl.Click += new System.EventHandler(this.t1matlbl_Click);
            // 
            // t1sa
            // 
            this.t1sa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1sa.Location = new System.Drawing.Point(177, 97);
            this.t1sa.Name = "t1sa";
            this.t1sa.Size = new System.Drawing.Size(40, 20);
            this.t1sa.TabIndex = 5;
            this.t1sa.Enter += new System.EventHandler(this.t1sa_Enter);
            // 
            // t1wt
            // 
            this.t1wt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1wt.Location = new System.Drawing.Point(131, 97);
            this.t1wt.Name = "t1wt";
            this.t1wt.Size = new System.Drawing.Size(40, 20);
            this.t1wt.TabIndex = 4;
            this.t1wt.TextChanged += new System.EventHandler(this.t1wt_TextChanged);
            this.t1wt.Enter += new System.EventHandler(this.t1wt_Enter);
            // 
            // t1gl
            // 
            this.t1gl.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1gl.Location = new System.Drawing.Point(85, 97);
            this.t1gl.MaxLength = 4;
            this.t1gl.Name = "t1gl";
            this.t1gl.Size = new System.Drawing.Size(40, 20);
            this.t1gl.TabIndex = 3;
            this.t1gl.TextChanged += new System.EventHandler(this.t1gl_TextChanged);
            this.t1gl.Enter += new System.EventHandler(this.t1gl_Enter);
            // 
            // t1mat
            // 
            this.t1mat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1mat.Location = new System.Drawing.Point(39, 97);
            this.t1mat.MaxLength = 2;
            this.t1mat.Name = "t1mat";
            this.t1mat.Size = new System.Drawing.Size(40, 20);
            this.t1mat.TabIndex = 2;
            this.t1mat.TextChanged += new System.EventHandler(this.t1mat_TextChanged_1);
            this.t1mat.Enter += new System.EventHandler(this.t1mat_Enter);
            // 
            // t1desclbl
            // 
            this.t1desclbl.AutoSize = true;
            this.t1desclbl.Location = new System.Drawing.Point(392, 12);
            this.t1desclbl.Name = "t1desclbl";
            this.t1desclbl.Size = new System.Drawing.Size(60, 13);
            this.t1desclbl.TabIndex = 3;
            this.t1desclbl.Text = "Description";
            // 
            // t1pcodelbl
            // 
            this.t1pcodelbl.AutoSize = true;
            this.t1pcodelbl.Location = new System.Drawing.Point(36, 12);
            this.t1pcodelbl.Name = "t1pcodelbl";
            this.t1pcodelbl.Size = new System.Drawing.Size(50, 13);
            this.t1pcodelbl.TabIndex = 2;
            this.t1pcodelbl.Text = "Partcode";
            // 
            // t1desc
            // 
            this.t1desc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1desc.Location = new System.Drawing.Point(395, 37);
            this.t1desc.Name = "t1desc";
            this.t1desc.Size = new System.Drawing.Size(278, 20);
            this.t1desc.TabIndex = 1;
            this.t1desc.Enter += new System.EventHandler(this.t1desc_Enter);
            // 
            // t1pcode
            // 
            this.t1pcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t1pcode.Location = new System.Drawing.Point(40, 37);
            this.t1pcode.Name = "t1pcode";
            this.t1pcode.Size = new System.Drawing.Size(200, 20);
            this.t1pcode.TabIndex = 0;
            this.t1pcode.TextChanged += new System.EventHandler(this.t1pcode_TextChanged);
            this.t1pcode.Enter += new System.EventHandler(this.t1pcode_Enter);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Transparent;
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.t2reflabel);
            this.tabPage2.Controls.Add(this.t2reftextbox);
            this.tabPage2.Controls.Add(this.dataGridView3);
            this.tabPage2.Controls.Add(this.t2jobnumberlabel);
            this.tabPage2.Controls.Add(this.t2qtylabel);
            this.tabPage2.Controls.Add(this.t2qtytextbox);
            this.tabPage2.Controls.Add(this.t2jobnumbertextbox);
            this.tabPage2.Controls.Add(this.t2reqcheckbox);
            this.tabPage2.Controls.Add(this.t2listfromclip);
            this.tabPage2.Controls.Add(this.t2importfromclip);
            this.tabPage2.Controls.Add(this.pictureBox3);
            this.tabPage2.Controls.Add(this.pictureBox2);
            this.tabPage2.Controls.Add(this.t2cleardata);
            this.tabPage2.Controls.Add(this.t2copy);
            this.tabPage2.Controls.Add(this.t2reset);
            this.tabPage2.Controls.Add(this.t2undoadd);
            this.tabPage2.Controls.Add(this.t2undosort);
            this.tabPage2.Controls.Add(this.t2addclear);
            this.tabPage2.Controls.Add(this.t2add);
            this.tabPage2.Controls.Add(this.t2convertlbl);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.t2salbl);
            this.tabPage2.Controls.Add(this.t2wtlbl);
            this.tabPage2.Controls.Add(this.t2gllbl);
            this.tabPage2.Controls.Add(this.t2matlbl);
            this.tabPage2.Controls.Add(this.t2sa);
            this.tabPage2.Controls.Add(this.t2wt);
            this.tabPage2.Controls.Add(this.t2gl);
            this.tabPage2.Controls.Add(this.t2mat);
            this.tabPage2.Controls.Add(this.t2desclbl);
            this.tabPage2.Controls.Add(this.t2pcodelbl);
            this.tabPage2.Controls.Add(this.t2desc);
            this.tabPage2.Controls.Add(this.t2pcode);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1183, 685);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Supports";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(229, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 65;
            this.label2.Text = "Status:*";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // t2reflabel
            // 
            this.t2reflabel.AutoSize = true;
            this.t2reflabel.Location = new System.Drawing.Point(377, 81);
            this.t2reflabel.Name = "t2reflabel";
            this.t2reflabel.Size = new System.Drawing.Size(57, 13);
            this.t2reflabel.TabIndex = 64;
            this.t2reflabel.Text = "Reference";
            this.t2reflabel.Visible = false;
            // 
            // t2reftextbox
            // 
            this.t2reftextbox.Location = new System.Drawing.Point(375, 97);
            this.t2reftextbox.Name = "t2reftextbox";
            this.t2reftextbox.Size = new System.Drawing.Size(100, 20);
            this.t2reftextbox.TabIndex = 8;
            this.t2reftextbox.Visible = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.t2reqbuilder1,
            this.t2reqbuilder2,
            this.t2reqbuilder3,
            this.t2reqbuilder4,
            this.t2reqbuilder5});
            this.dataGridView3.Location = new System.Drawing.Point(2, 473);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.Size = new System.Drawing.Size(1174, 209);
            this.dataGridView3.TabIndex = 62;
            this.dataGridView3.Visible = false;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // t2reqbuilder1
            // 
            this.t2reqbuilder1.HeaderText = "Partcode";
            this.t2reqbuilder1.Name = "t2reqbuilder1";
            // 
            // t2reqbuilder2
            // 
            this.t2reqbuilder2.HeaderText = "Qty";
            this.t2reqbuilder2.Name = "t2reqbuilder2";
            // 
            // t2reqbuilder3
            // 
            this.t2reqbuilder3.HeaderText = "JobNumber";
            this.t2reqbuilder3.Name = "t2reqbuilder3";
            // 
            // t2reqbuilder4
            // 
            this.t2reqbuilder4.HeaderText = "Reference";
            this.t2reqbuilder4.Name = "t2reqbuilder4";
            // 
            // t2reqbuilder5
            // 
            this.t2reqbuilder5.HeaderText = "Lot/Serial";
            this.t2reqbuilder5.Name = "t2reqbuilder5";
            // 
            // t2jobnumberlabel
            // 
            this.t2jobnumberlabel.AutoSize = true;
            this.t2jobnumberlabel.Location = new System.Drawing.Point(271, 81);
            this.t2jobnumberlabel.Name = "t2jobnumberlabel";
            this.t2jobnumberlabel.Size = new System.Drawing.Size(62, 13);
            this.t2jobnumberlabel.TabIndex = 61;
            this.t2jobnumberlabel.Text = "Job number";
            this.t2jobnumberlabel.Visible = false;
            // 
            // t2qtylabel
            // 
            this.t2qtylabel.AutoSize = true;
            this.t2qtylabel.Location = new System.Drawing.Point(229, 81);
            this.t2qtylabel.Name = "t2qtylabel";
            this.t2qtylabel.Size = new System.Drawing.Size(29, 13);
            this.t2qtylabel.TabIndex = 60;
            this.t2qtylabel.Text = "QTY";
            this.t2qtylabel.Visible = false;
            this.t2qtylabel.Click += new System.EventHandler(this.label2_Click);
            // 
            // t2qtytextbox
            // 
            this.t2qtytextbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2qtytextbox.Location = new System.Drawing.Point(223, 97);
            this.t2qtytextbox.Name = "t2qtytextbox";
            this.t2qtytextbox.Size = new System.Drawing.Size(40, 20);
            this.t2qtytextbox.TabIndex = 6;
            this.t2qtytextbox.Visible = false;
            this.t2qtytextbox.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            this.t2qtytextbox.Enter += new System.EventHandler(this.t2qtytextbox_Enter);
            // 
            // t2jobnumbertextbox
            // 
            this.t2jobnumbertextbox.Location = new System.Drawing.Point(269, 97);
            this.t2jobnumbertextbox.Name = "t2jobnumbertextbox";
            this.t2jobnumbertextbox.Size = new System.Drawing.Size(100, 20);
            this.t2jobnumbertextbox.TabIndex = 7;
            this.t2jobnumbertextbox.Visible = false;
            // 
            // t2reqcheckbox
            // 
            this.t2reqcheckbox.AutoSize = true;
            this.t2reqcheckbox.Location = new System.Drawing.Point(592, 77);
            this.t2reqcheckbox.Name = "t2reqcheckbox";
            this.t2reqcheckbox.Size = new System.Drawing.Size(81, 17);
            this.t2reqcheckbox.TabIndex = 57;
            this.t2reqcheckbox.Text = "Req Builder";
            this.t2reqcheckbox.UseVisualStyleBackColor = true;
            this.t2reqcheckbox.CheckedChanged += new System.EventHandler(this.t2reqcheckbox_CheckedChanged);
            // 
            // t2listfromclip
            // 
            this.t2listfromclip.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.t2listfromclip.DisplayMember = "Value";
            this.t2listfromclip.FormattingEnabled = true;
            this.t2listfromclip.Location = new System.Drawing.Point(921, 207);
            this.t2listfromclip.Name = "t2listfromclip";
            this.t2listfromclip.Size = new System.Drawing.Size(190, 21);
            this.t2listfromclip.TabIndex = 16;
            this.t2listfromclip.ValueMember = "Value";
            this.t2listfromclip.SelectedIndexChanged += new System.EventHandler(this.t2listfromclip_SelectedIndexChanged);
            // 
            // t2importfromclip
            // 
            this.t2importfromclip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.t2importfromclip.ContextMenuStrip = this.t2importsupt;
            this.t2importfromclip.Location = new System.Drawing.Point(812, 201);
            this.t2importfromclip.Name = "t2importfromclip";
            this.t2importfromclip.Size = new System.Drawing.Size(105, 30);
            this.t2importfromclip.TabIndex = 55;
            this.t2importfromclip.Text = "Import List*";
            this.t2importfromclip.UseVisualStyleBackColor = true;
            this.t2importfromclip.Click += new System.EventHandler(this.t2importfromclip_Click);
            // 
            // t2importsupt
            // 
            this.t2importsupt.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importFromClipboardDescMatGLWtSAToolStripMenuItem,
            this.importFromFileToolStripMenuItem});
            this.t2importsupt.Name = "t2importsupt";
            this.t2importsupt.Size = new System.Drawing.Size(339, 48);
            this.t2importsupt.Opening += new System.ComponentModel.CancelEventHandler(this.t2importsupt_Opening);
            // 
            // importFromClipboardDescMatGLWtSAToolStripMenuItem
            // 
            this.importFromClipboardDescMatGLWtSAToolStripMenuItem.Name = "importFromClipboardDescMatGLWtSAToolStripMenuItem";
            this.importFromClipboardDescMatGLWtSAToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.importFromClipboardDescMatGLWtSAToolStripMenuItem.Text = "Import from Clipboard - Desc - Mat - GL - Wt - SA";
            this.importFromClipboardDescMatGLWtSAToolStripMenuItem.Click += new System.EventHandler(this.importFromClipboardDescMatGLWtSAToolStripMenuItem_Click);
            // 
            // importFromFileToolStripMenuItem
            // 
            this.importFromFileToolStripMenuItem.Name = "importFromFileToolStripMenuItem";
            this.importFromFileToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.importFromFileToolStripMenuItem.Text = "Import From File";
            this.importFromFileToolStripMenuItem.Click += new System.EventHandler(this.importFromFileToolStripMenuItem_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(325, 28);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(64, 42);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 23;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(806, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(369, 184);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // t2cleardata
            // 
            this.t2cleardata.Location = new System.Drawing.Point(220, 186);
            this.t2cleardata.Name = "t2cleardata";
            this.t2cleardata.Size = new System.Drawing.Size(85, 28);
            this.t2cleardata.TabIndex = 21;
            this.t2cleardata.Text = "Clear Data";
            this.t2cleardata.UseVisualStyleBackColor = true;
            this.t2cleardata.Click += new System.EventHandler(this.t2cleardata_Click);
            // 
            // t2copy
            // 
            this.t2copy.ContextMenuStrip = this.contextMenuStrip1;
            this.t2copy.Location = new System.Drawing.Point(311, 186);
            this.t2copy.Name = "t2copy";
            this.t2copy.Size = new System.Drawing.Size(85, 28);
            this.t2copy.TabIndex = 20;
            this.t2copy.Text = "Copy*";
            this.t2copy.UseVisualStyleBackColor = true;
            this.t2copy.Click += new System.EventHandler(this.t2copy_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyAsReqToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(140, 26);
            // 
            // copyAsReqToolStripMenuItem
            // 
            this.copyAsReqToolStripMenuItem.Name = "copyAsReqToolStripMenuItem";
            this.copyAsReqToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.copyAsReqToolStripMenuItem.Text = "Copy as Req";
            this.copyAsReqToolStripMenuItem.Click += new System.EventHandler(this.copyAsReqToolStripMenuItem_Click);
            // 
            // t2reset
            // 
            this.t2reset.Location = new System.Drawing.Point(220, 138);
            this.t2reset.Name = "t2reset";
            this.t2reset.Size = new System.Drawing.Size(85, 28);
            this.t2reset.TabIndex = 19;
            this.t2reset.Text = "Reset Fields";
            this.t2reset.UseVisualStyleBackColor = true;
            this.t2reset.Click += new System.EventHandler(this.t2reset_Click);
            // 
            // t2undoadd
            // 
            this.t2undoadd.Location = new System.Drawing.Point(129, 186);
            this.t2undoadd.Name = "t2undoadd";
            this.t2undoadd.Size = new System.Drawing.Size(85, 28);
            this.t2undoadd.TabIndex = 18;
            this.t2undoadd.Text = "Undo Add";
            this.t2undoadd.UseVisualStyleBackColor = true;
            this.t2undoadd.Click += new System.EventHandler(this.t2undoadd_Click);
            // 
            // t2undosort
            // 
            this.t2undosort.Location = new System.Drawing.Point(129, 138);
            this.t2undosort.Name = "t2undosort";
            this.t2undosort.Size = new System.Drawing.Size(85, 28);
            this.t2undosort.TabIndex = 17;
            this.t2undosort.Text = "Undo Sort";
            this.t2undosort.UseVisualStyleBackColor = true;
            this.t2undosort.Click += new System.EventHandler(this.t2undosort_Click);
            // 
            // t2addclear
            // 
            this.t2addclear.ContextMenuStrip = this.t2addclearcm;
            this.t2addclear.Location = new System.Drawing.Point(39, 186);
            this.t2addclear.Name = "t2addclear";
            this.t2addclear.Size = new System.Drawing.Size(85, 28);
            this.t2addclear.TabIndex = 16;
            this.t2addclear.Text = "Add_Clear*";
            this.t2addclear.UseVisualStyleBackColor = true;
            this.t2addclear.Click += new System.EventHandler(this.t2addclear_Click);
            // 
            // t2addclearcm
            // 
            this.t2addclearcm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2});
            this.t2addclearcm.Name = "contextMenuStrip1";
            this.t2addclearcm.Size = new System.Drawing.Size(191, 26);
            this.t2addclearcm.Opening += new System.ComponentModel.CancelEventHandler(this.t2addclearcm_Opening);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(190, 22);
            this.toolStripMenuItem2.Text = "Add as correction (04)";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // t2add
            // 
            this.t2add.ContextMenuStrip = this.t2addcm;
            this.t2add.Location = new System.Drawing.Point(38, 138);
            this.t2add.Name = "t2add";
            this.t2add.Size = new System.Drawing.Size(85, 28);
            this.t2add.TabIndex = 15;
            this.t2add.Text = "Add*";
            this.t2add.UseVisualStyleBackColor = true;
            this.t2add.Click += new System.EventHandler(this.t2add_Click);
            // 
            // t2addcm
            // 
            this.t2addcm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.t2addcm.Name = "contextMenuStrip1";
            this.t2addcm.Size = new System.Drawing.Size(191, 26);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(190, 22);
            this.toolStripMenuItem1.Text = "Add as correction (04)";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // t2convertlbl
            // 
            this.t2convertlbl.AutoSize = true;
            this.t2convertlbl.ForeColor = System.Drawing.Color.Blue;
            this.t2convertlbl.Location = new System.Drawing.Point(345, 37);
            this.t2convertlbl.Name = "t2convertlbl";
            this.t2convertlbl.Size = new System.Drawing.Size(19, 13);
            this.t2convertlbl.TabIndex = 14;
            this.t2convertlbl.Text = "<--";
            this.t2convertlbl.Click += new System.EventHandler(this.t2convertlbl_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.t2Action,
            this.t2ItemorBranch,
            this.t2branchplant,
            this.t2shortid,
            this.t2itemnumber,
            this.t2thirditemnumber,
            this.t2descriptionone,
            this.t2descriptiontwo,
            this.t2searchtext,
            this.t2comm,
            this.t2subcomm,
            this.t2sizeone,
            this.t2sizetwo,
            this.t2sched,
            this.t2ratgec,
            this.t2specgrade,
            this.t2laborgrp,
            this.t2mtlgrp,
            this.t2pbcodeone,
            this.t2pbcodetwo,
            this.t2pbcodethree,
            this.t2uom,
            this.t2wtum,
            this.t2voluom,
            this.t2classcode,
            this.t2lotproctype,
            this.t2countryreqd,
            this.t2stockingtype,
            this.t2lnty,
            this.t2shelfdays,
            this.t2weightprice,
            this.t2surfacearea,
            this.t2templateid,
            this.t2projmfgreqd});
            this.dataGridView2.Location = new System.Drawing.Point(2, 243);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.Size = new System.Drawing.Size(1174, 440);
            this.dataGridView2.TabIndex = 12;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // t2Action
            // 
            this.t2Action.HeaderText = "Action";
            this.t2Action.Name = "t2Action";
            // 
            // t2ItemorBranch
            // 
            this.t2ItemorBranch.HeaderText = "Item or Branch";
            this.t2ItemorBranch.Name = "t2ItemorBranch";
            // 
            // t2branchplant
            // 
            this.t2branchplant.HeaderText = "Branch Plant";
            this.t2branchplant.Name = "t2branchplant";
            // 
            // t2shortid
            // 
            this.t2shortid.HeaderText = "Short ID";
            this.t2shortid.Name = "t2shortid";
            // 
            // t2itemnumber
            // 
            this.t2itemnumber.HeaderText = "Item Number";
            this.t2itemnumber.Name = "t2itemnumber";
            // 
            // t2thirditemnumber
            // 
            this.t2thirditemnumber.HeaderText = "3rd Item Number";
            this.t2thirditemnumber.Name = "t2thirditemnumber";
            // 
            // t2descriptionone
            // 
            this.t2descriptionone.HeaderText = "Description 1";
            this.t2descriptionone.Name = "t2descriptionone";
            // 
            // t2descriptiontwo
            // 
            this.t2descriptiontwo.HeaderText = "Description 2";
            this.t2descriptiontwo.Name = "t2descriptiontwo";
            // 
            // t2searchtext
            // 
            this.t2searchtext.HeaderText = "Search Text";
            this.t2searchtext.Name = "t2searchtext";
            // 
            // t2comm
            // 
            this.t2comm.HeaderText = "Comm";
            this.t2comm.Name = "t2comm";
            // 
            // t2subcomm
            // 
            this.t2subcomm.HeaderText = "Sub Comm";
            this.t2subcomm.Name = "t2subcomm";
            // 
            // t2sizeone
            // 
            this.t2sizeone.HeaderText = "Size 1";
            this.t2sizeone.Name = "t2sizeone";
            // 
            // t2sizetwo
            // 
            this.t2sizetwo.HeaderText = "Size 2";
            this.t2sizetwo.Name = "t2sizetwo";
            // 
            // t2sched
            // 
            this.t2sched.HeaderText = "Sch";
            this.t2sched.Name = "t2sched";
            // 
            // t2ratgec
            // 
            this.t2ratgec.HeaderText = "Rating";
            this.t2ratgec.Name = "t2ratgec";
            // 
            // t2specgrade
            // 
            this.t2specgrade.HeaderText = "Spec Grade";
            this.t2specgrade.Name = "t2specgrade";
            // 
            // t2laborgrp
            // 
            this.t2laborgrp.HeaderText = "Labor Grp";
            this.t2laborgrp.Name = "t2laborgrp";
            // 
            // t2mtlgrp
            // 
            this.t2mtlgrp.HeaderText = "Mtl Grp";
            this.t2mtlgrp.Name = "t2mtlgrp";
            // 
            // t2pbcodeone
            // 
            this.t2pbcodeone.HeaderText = "P/B Code1";
            this.t2pbcodeone.Name = "t2pbcodeone";
            // 
            // t2pbcodetwo
            // 
            this.t2pbcodetwo.HeaderText = "P/B Code2";
            this.t2pbcodetwo.Name = "t2pbcodetwo";
            // 
            // t2pbcodethree
            // 
            this.t2pbcodethree.HeaderText = "P/B Code3";
            this.t2pbcodethree.Name = "t2pbcodethree";
            // 
            // t2uom
            // 
            this.t2uom.HeaderText = "Uom";
            this.t2uom.Name = "t2uom";
            // 
            // t2wtum
            // 
            this.t2wtum.HeaderText = "Wt UM";
            this.t2wtum.Name = "t2wtum";
            // 
            // t2voluom
            // 
            this.t2voluom.HeaderText = "Vol UOM";
            this.t2voluom.Name = "t2voluom";
            // 
            // t2classcode
            // 
            this.t2classcode.HeaderText = "Class Code";
            this.t2classcode.Name = "t2classcode";
            // 
            // t2lotproctype
            // 
            this.t2lotproctype.HeaderText = "Lot Proc Type";
            this.t2lotproctype.Name = "t2lotproctype";
            // 
            // t2countryreqd
            // 
            this.t2countryreqd.HeaderText = "Country Reqd";
            this.t2countryreqd.Name = "t2countryreqd";
            // 
            // t2stockingtype
            // 
            this.t2stockingtype.HeaderText = "Stocking Type";
            this.t2stockingtype.Name = "t2stockingtype";
            // 
            // t2lnty
            // 
            this.t2lnty.HeaderText = "Ln Ty";
            this.t2lnty.Name = "t2lnty";
            // 
            // t2shelfdays
            // 
            this.t2shelfdays.HeaderText = "Shelf Days";
            this.t2shelfdays.Name = "t2shelfdays";
            // 
            // t2weightprice
            // 
            this.t2weightprice.HeaderText = "Weight/Price";
            this.t2weightprice.Name = "t2weightprice";
            // 
            // t2surfacearea
            // 
            this.t2surfacearea.HeaderText = "Surface Area";
            this.t2surfacearea.Name = "t2surfacearea";
            // 
            // t2templateid
            // 
            this.t2templateid.HeaderText = "Template ID";
            this.t2templateid.Name = "t2templateid";
            // 
            // t2projmfgreqd
            // 
            this.t2projmfgreqd.HeaderText = "Prof Mfg Reqd";
            this.t2projmfgreqd.Name = "t2projmfgreqd";
            // 
            // t2salbl
            // 
            this.t2salbl.AutoSize = true;
            this.t2salbl.Location = new System.Drawing.Point(186, 81);
            this.t2salbl.Name = "t2salbl";
            this.t2salbl.Size = new System.Drawing.Size(21, 13);
            this.t2salbl.TabIndex = 11;
            this.t2salbl.Text = "SA";
            // 
            // t2wtlbl
            // 
            this.t2wtlbl.AutoSize = true;
            this.t2wtlbl.Location = new System.Drawing.Point(130, 81);
            this.t2wtlbl.Name = "t2wtlbl";
            this.t2wtlbl.Size = new System.Drawing.Size(41, 13);
            this.t2wtlbl.TabIndex = 10;
            this.t2wtlbl.Text = "Weight";
            // 
            // t2gllbl
            // 
            this.t2gllbl.AutoSize = true;
            this.t2gllbl.ForeColor = System.Drawing.Color.Blue;
            this.t2gllbl.Location = new System.Drawing.Point(82, 81);
            this.t2gllbl.Name = "t2gllbl";
            this.t2gllbl.Size = new System.Drawing.Size(49, 13);
            this.t2gllbl.TabIndex = 9;
            this.t2gllbl.Text = "GL Class";
            this.t2gllbl.Click += new System.EventHandler(this.t2gllbl_Click);
            // 
            // t2matlbl
            // 
            this.t2matlbl.AutoSize = true;
            this.t2matlbl.ForeColor = System.Drawing.Color.Blue;
            this.t2matlbl.Location = new System.Drawing.Point(36, 81);
            this.t2matlbl.Name = "t2matlbl";
            this.t2matlbl.Size = new System.Drawing.Size(44, 13);
            this.t2matlbl.TabIndex = 8;
            this.t2matlbl.Text = "Material";
            this.t2matlbl.Click += new System.EventHandler(this.t2matlbl_Click);
            // 
            // t2sa
            // 
            this.t2sa.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2sa.Location = new System.Drawing.Point(177, 97);
            this.t2sa.Name = "t2sa";
            this.t2sa.Size = new System.Drawing.Size(40, 20);
            this.t2sa.TabIndex = 5;
            this.t2sa.Enter += new System.EventHandler(this.t2sa_Enter);
            // 
            // t2wt
            // 
            this.t2wt.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2wt.Location = new System.Drawing.Point(131, 97);
            this.t2wt.Name = "t2wt";
            this.t2wt.Size = new System.Drawing.Size(40, 20);
            this.t2wt.TabIndex = 4;
            this.t2wt.Enter += new System.EventHandler(this.t2wt_Enter);
            // 
            // t2gl
            // 
            this.t2gl.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2gl.Location = new System.Drawing.Point(85, 97);
            this.t2gl.Name = "t2gl";
            this.t2gl.Size = new System.Drawing.Size(40, 20);
            this.t2gl.TabIndex = 3;
            this.t2gl.TextChanged += new System.EventHandler(this.t2gl_TextChanged);
            this.t2gl.Enter += new System.EventHandler(this.t2gl_Enter);
            this.t2gl.GotFocus += new System.EventHandler(this.t2gl_GotFocus);
            // 
            // t2mat
            // 
            this.t2mat.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2mat.Location = new System.Drawing.Point(39, 97);
            this.t2mat.Name = "t2mat";
            this.t2mat.Size = new System.Drawing.Size(40, 20);
            this.t2mat.TabIndex = 2;
            this.t2mat.TextChanged += new System.EventHandler(this.t2mat_TextChanged_1);
            this.t2mat.Enter += new System.EventHandler(this.t2mat_Enter);
            // 
            // t2desclbl
            // 
            this.t2desclbl.AutoSize = true;
            this.t2desclbl.Location = new System.Drawing.Point(392, 12);
            this.t2desclbl.Name = "t2desclbl";
            this.t2desclbl.Size = new System.Drawing.Size(60, 13);
            this.t2desclbl.TabIndex = 3;
            this.t2desclbl.Text = "Description";
            // 
            // t2pcodelbl
            // 
            this.t2pcodelbl.AutoSize = true;
            this.t2pcodelbl.Location = new System.Drawing.Point(36, 12);
            this.t2pcodelbl.Name = "t2pcodelbl";
            this.t2pcodelbl.Size = new System.Drawing.Size(50, 13);
            this.t2pcodelbl.TabIndex = 2;
            this.t2pcodelbl.Text = "Partcode";
            // 
            // t2desc
            // 
            this.t2desc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2desc.Location = new System.Drawing.Point(395, 37);
            this.t2desc.Name = "t2desc";
            this.t2desc.Size = new System.Drawing.Size(278, 20);
            this.t2desc.TabIndex = 1;
            this.t2desc.TextChanged += new System.EventHandler(this.t2desc_TextChanged_1);
            this.t2desc.Enter += new System.EventHandler(this.t2desc_Enter);
            // 
            // t2pcode
            // 
            this.t2pcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t2pcode.Location = new System.Drawing.Point(40, 37);
            this.t2pcode.Name = "t2pcode";
            this.t2pcode.Size = new System.Drawing.Size(278, 20);
            this.t2pcode.TabIndex = 0;
            this.t2pcode.TextChanged += new System.EventHandler(this.t2pcode_TextChanged_1);
            this.t2pcode.Enter += new System.EventHandler(this.t2pcode_Enter);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Transparent;
            this.tabPage3.Controls.Add(this.pictureBox5);
            this.tabPage3.Controls.Add(this.ChkDesc);
            this.tabPage3.Controls.Add(this.t3breakout);
            this.tabPage3.Controls.Add(this.t3pasteandbreakout);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.t3clear);
            this.tabPage3.Controls.Add(this.t3selectallandcopy);
            this.tabPage3.Controls.Add(this.t3pasteandcheckbutton);
            this.tabPage3.Controls.Add(this.listBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1183, 685);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Partcodes / Breakout";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(975, 588);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(193, 92);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 22;
            this.pictureBox5.TabStop = false;
            // 
            // ChkDesc
            // 
            this.ChkDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ChkDesc.Location = new System.Drawing.Point(139, 639);
            this.ChkDesc.Name = "ChkDesc";
            this.ChkDesc.Size = new System.Drawing.Size(118, 31);
            this.ChkDesc.TabIndex = 10;
            this.ChkDesc.Text = "Check Desc";
            this.ChkDesc.UseVisualStyleBackColor = true;
            this.ChkDesc.Click += new System.EventHandler(this.button2_Click);
            // 
            // t3breakout
            // 
            this.t3breakout.AllowUserToAddRows = false;
            this.t3breakout.AllowUserToDeleteRows = false;
            this.t3breakout.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.t3breakout.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.t3breakout.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.t3breakout.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.t3breakout.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.t3subcom,
            this.t3size1,
            this.t3size2,
            this.t3sch,
            this.t3rating,
            this.t3sgc,
            this.Desc,
            this.Partcode});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.t3breakout.DefaultCellStyle = dataGridViewCellStyle1;
            this.t3breakout.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.t3breakout.Location = new System.Drawing.Point(383, 26);
            this.t3breakout.Name = "t3breakout";
            this.t3breakout.RowHeadersVisible = false;
            this.t3breakout.RowTemplate.Height = 15;
            this.t3breakout.Size = new System.Drawing.Size(785, 556);
            this.t3breakout.TabIndex = 9;
            this.t3breakout.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.t3breakout_CellContentClick);
            // 
            // t3subcom
            // 
            this.t3subcom.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.t3subcom.FillWeight = 50.33841F;
            this.t3subcom.HeaderText = "SUBCOMM";
            this.t3subcom.Name = "t3subcom";
            this.t3subcom.Width = 95;
            // 
            // t3size1
            // 
            this.t3size1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.t3size1.FillWeight = 50.33841F;
            this.t3size1.HeaderText = "SIZE1";
            this.t3size1.Name = "t3size1";
            this.t3size1.Width = 40;
            // 
            // t3size2
            // 
            this.t3size2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.t3size2.FillWeight = 50.33841F;
            this.t3size2.HeaderText = "SIZE2";
            this.t3size2.Name = "t3size2";
            this.t3size2.Width = 40;
            // 
            // t3sch
            // 
            this.t3sch.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.t3sch.FillWeight = 50.33841F;
            this.t3sch.HeaderText = "SCH";
            this.t3sch.Name = "t3sch";
            this.t3sch.Width = 50;
            // 
            // t3rating
            // 
            this.t3rating.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.t3rating.FillWeight = 50.33841F;
            this.t3rating.HeaderText = "RATING";
            this.t3rating.Name = "t3rating";
            this.t3rating.Width = 50;
            // 
            // t3sgc
            // 
            this.t3sgc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.t3sgc.FillWeight = 50.33841F;
            this.t3sgc.HeaderText = "SGC";
            this.t3sgc.Name = "t3sgc";
            // 
            // Desc
            // 
            this.Desc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Desc.FillWeight = 397.9695F;
            this.Desc.HeaderText = "Desc";
            this.Desc.Name = "Desc";
            this.Desc.Width = 250;
            // 
            // Partcode
            // 
            this.Partcode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Partcode.HeaderText = "Partcode";
            this.Partcode.Name = "Partcode";
            this.Partcode.Width = 150;
            // 
            // t3pasteandbreakout
            // 
            this.t3pasteandbreakout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.t3pasteandbreakout.ContextMenuStrip = this.t3importfibreakout;
            this.t3pasteandbreakout.Location = new System.Drawing.Point(15, 639);
            this.t3pasteandbreakout.Name = "t3pasteandbreakout";
            this.t3pasteandbreakout.Size = new System.Drawing.Size(118, 31);
            this.t3pasteandbreakout.TabIndex = 8;
            this.t3pasteandbreakout.Text = "Paste and Breakout*";
            this.t3pasteandbreakout.UseVisualStyleBackColor = true;
            this.t3pasteandbreakout.Click += new System.EventHandler(this.t3pasteandbreakout_Click);
            // 
            // t3importfibreakout
            // 
            this.t3importfibreakout.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4});
            this.t3importfibreakout.Name = "contextMenuStrip1";
            this.t3importfibreakout.Size = new System.Drawing.Size(218, 26);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(217, 22);
            this.toolStripMenuItem4.Text = "Import From Missing Items";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "PartCode Existance Checker";
            // 
            // t3clear
            // 
            this.t3clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.t3clear.Location = new System.Drawing.Point(255, 604);
            this.t3clear.Name = "t3clear";
            this.t3clear.Size = new System.Drawing.Size(110, 31);
            this.t3clear.TabIndex = 5;
            this.t3clear.Text = "Clear";
            this.t3clear.UseVisualStyleBackColor = true;
            this.t3clear.Click += new System.EventHandler(this.t3clear_Click);
            // 
            // t3selectallandcopy
            // 
            this.t3selectallandcopy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.t3selectallandcopy.ContextMenuStrip = this.t3copyjdedesc;
            this.t3selectallandcopy.Location = new System.Drawing.Point(139, 604);
            this.t3selectallandcopy.Name = "t3selectallandcopy";
            this.t3selectallandcopy.Size = new System.Drawing.Size(110, 31);
            this.t3selectallandcopy.TabIndex = 4;
            this.t3selectallandcopy.Text = "Selct All and Copy*";
            this.t3selectallandcopy.UseVisualStyleBackColor = true;
            this.t3selectallandcopy.Click += new System.EventHandler(this.t3selectallandcopy_Click);
            // 
            // t3copyjdedesc
            // 
            this.t3copyjdedesc.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem6});
            this.t3copyjdedesc.Name = "contextMenuStrip1";
            this.t3copyjdedesc.Size = new System.Drawing.Size(152, 26);
            this.t3copyjdedesc.Opening += new System.ComponentModel.CancelEventHandler(this.t3copyjdedesc_Opening);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(151, 22);
            this.toolStripMenuItem6.Text = "Copy JDE Desc";
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // t3pasteandcheckbutton
            // 
            this.t3pasteandcheckbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.t3pasteandcheckbutton.ContextMenuStrip = this.t3importfromimport;
            this.t3pasteandcheckbutton.Location = new System.Drawing.Point(15, 604);
            this.t3pasteandcheckbutton.Name = "t3pasteandcheckbutton";
            this.t3pasteandcheckbutton.Size = new System.Drawing.Size(118, 31);
            this.t3pasteandcheckbutton.TabIndex = 3;
            this.t3pasteandcheckbutton.Text = "Paste and Check*";
            this.t3pasteandcheckbutton.UseVisualStyleBackColor = true;
            this.t3pasteandcheckbutton.Click += new System.EventHandler(this.t3pasteandcheckbutton_Click);
            // 
            // t3importfromimport
            // 
            this.t3importfromimport.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3});
            this.t3importfromimport.Name = "contextMenuStrip1";
            this.t3importfromimport.Size = new System.Drawing.Size(218, 26);
            this.t3importfromimport.Opening += new System.ComponentModel.CancelEventHandler(this.t3importfromimport_Opening);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(217, 22);
            this.toolStripMenuItem3.Text = "Import From Missing Items";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click_1);
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(15, 26);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBox1.Size = new System.Drawing.Size(362, 556);
            this.listBox1.TabIndex = 2;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.listBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listBox1_KeyDown);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Transparent;
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Controls.Add(this.t4ClearData);
            this.tabPage4.Controls.Add(this.t4ClearList);
            this.tabPage4.Controls.Add(this.t4AddToList);
            this.tabPage4.Controls.Add(this.t4BarcodeBomList);
            this.tabPage4.Controls.Add(this.t4LoadBomBarcodes);
            this.tabPage4.Controls.Add(this.t4refdwgtb);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.T4LoadBom);
            this.tabPage4.Controls.Add(this.pictureBox4);
            this.tabPage4.Controls.Add(this.t4dgv);
            this.tabPage4.Controls.Add(this.t4spooltb);
            this.tabPage4.Controls.Add(this.t4jobtb);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1183, 685);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Bom Lookup";
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.t4rb2);
            this.groupBox1.Controls.Add(this.t4rb1);
            this.groupBox1.Location = new System.Drawing.Point(196, 132);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(144, 84);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Source";
            // 
            // t4rb2
            // 
            this.t4rb2.AutoSize = true;
            this.t4rb2.Location = new System.Drawing.Point(6, 44);
            this.t4rb2.Name = "t4rb2";
            this.t4rb2.Size = new System.Drawing.Size(75, 17);
            this.t4rb2.TabIndex = 37;
            this.t4rb2.Text = "Piecemark";
            this.t4rb2.UseVisualStyleBackColor = true;
            // 
            // t4rb1
            // 
            this.t4rb1.AutoSize = true;
            this.t4rb1.Checked = true;
            this.t4rb1.Location = new System.Drawing.Point(6, 19);
            this.t4rb1.Name = "t4rb1";
            this.t4rb1.Size = new System.Drawing.Size(100, 17);
            this.t4rb1.TabIndex = 36;
            this.t4rb1.TabStop = true;
            this.t4rb1.Text = "Reference Dwg";
            this.t4rb1.UseVisualStyleBackColor = true;
            // 
            // t4ClearData
            // 
            this.t4ClearData.Location = new System.Drawing.Point(38, 185);
            this.t4ClearData.Name = "t4ClearData";
            this.t4ClearData.Size = new System.Drawing.Size(85, 28);
            this.t4ClearData.TabIndex = 35;
            this.t4ClearData.Text = "Clear Data";
            this.t4ClearData.UseVisualStyleBackColor = true;
            this.t4ClearData.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // t4ClearList
            // 
            this.t4ClearList.Location = new System.Drawing.Point(576, 82);
            this.t4ClearList.Name = "t4ClearList";
            this.t4ClearList.Size = new System.Drawing.Size(89, 28);
            this.t4ClearList.TabIndex = 34;
            this.t4ClearList.Text = "Clear List";
            this.t4ClearList.UseVisualStyleBackColor = true;
            this.t4ClearList.Click += new System.EventHandler(this.t4ClearList_Click);
            // 
            // t4AddToList
            // 
            this.t4AddToList.Location = new System.Drawing.Point(576, 37);
            this.t4AddToList.Name = "t4AddToList";
            this.t4AddToList.Size = new System.Drawing.Size(89, 28);
            this.t4AddToList.TabIndex = 33;
            this.t4AddToList.Text = "Add to List";
            this.t4AddToList.UseVisualStyleBackColor = true;
            this.t4AddToList.Click += new System.EventHandler(this.button4_Click);
            // 
            // t4BarcodeBomList
            // 
            this.t4BarcodeBomList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.t4BarcodeBomList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bcodes});
            this.t4BarcodeBomList.Location = new System.Drawing.Point(435, 37);
            this.t4BarcodeBomList.Name = "t4BarcodeBomList";
            this.t4BarcodeBomList.Size = new System.Drawing.Size(135, 128);
            this.t4BarcodeBomList.TabIndex = 32;
            // 
            // bcodes
            // 
            this.bcodes.HeaderText = "Barcodes";
            this.bcodes.Name = "bcodes";
            // 
            // t4LoadBomBarcodes
            // 
            this.t4LoadBomBarcodes.Location = new System.Drawing.Point(435, 185);
            this.t4LoadBomBarcodes.Name = "t4LoadBomBarcodes";
            this.t4LoadBomBarcodes.Size = new System.Drawing.Size(137, 28);
            this.t4LoadBomBarcodes.TabIndex = 31;
            this.t4LoadBomBarcodes.Text = "Load BOM Barcodes";
            this.t4LoadBomBarcodes.UseVisualStyleBackColor = true;
            this.t4LoadBomBarcodes.Click += new System.EventHandler(this.button3_Click);
            // 
            // t4refdwgtb
            // 
            this.t4refdwgtb.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.t4refdwgtb.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t4refdwgtb.Location = new System.Drawing.Point(38, 82);
            this.t4refdwgtb.Name = "t4refdwgtb";
            this.t4refdwgtb.Size = new System.Drawing.Size(191, 20);
            this.t4refdwgtb.TabIndex = 30;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(193, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 29;
            this.label4.Text = "Spool Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "Job Number";
            // 
            // T4LoadBom
            // 
            this.T4LoadBom.Location = new System.Drawing.Point(38, 138);
            this.T4LoadBom.Name = "T4LoadBom";
            this.T4LoadBom.Size = new System.Drawing.Size(85, 28);
            this.T4LoadBom.TabIndex = 27;
            this.T4LoadBom.Text = "Load BOM";
            this.T4LoadBom.UseVisualStyleBackColor = true;
            this.T4LoadBom.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(806, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(369, 184);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 26;
            this.pictureBox4.TabStop = false;
            // 
            // t4dgv
            // 
            this.t4dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.t4dgv.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.t4trans,
            this.t4iso,
            this.SPEC,
            this.t4itemcode,
            this.t4clientdesc,
            this.t4qty,
            this.t4pcode,
            this.t4desc});
            this.t4dgv.Location = new System.Drawing.Point(1, 243);
            this.t4dgv.Name = "t4dgv";
            this.t4dgv.RowHeadersVisible = false;
            this.t4dgv.Size = new System.Drawing.Size(1174, 440);
            this.t4dgv.TabIndex = 25;
            // 
            // t4trans
            // 
            this.t4trans.HeaderText = "Trans";
            this.t4trans.Name = "t4trans";
            // 
            // t4iso
            // 
            this.t4iso.HeaderText = "ISO/PCMK";
            this.t4iso.Name = "t4iso";
            // 
            // SPEC
            // 
            this.SPEC.HeaderText = "Spec";
            this.SPEC.Name = "SPEC";
            // 
            // t4itemcode
            // 
            this.t4itemcode.HeaderText = "ItemCode";
            this.t4itemcode.Name = "t4itemcode";
            // 
            // t4clientdesc
            // 
            this.t4clientdesc.HeaderText = "Client Desc";
            this.t4clientdesc.Name = "t4clientdesc";
            // 
            // t4qty
            // 
            this.t4qty.HeaderText = "Qty";
            this.t4qty.Name = "t4qty";
            // 
            // t4pcode
            // 
            this.t4pcode.HeaderText = "Partcode";
            this.t4pcode.Name = "t4pcode";
            // 
            // t4desc
            // 
            this.t4desc.HeaderText = "Description";
            this.t4desc.Name = "t4desc";
            // 
            // t4spooltb
            // 
            this.t4spooltb.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t4spooltb.Location = new System.Drawing.Point(196, 37);
            this.t4spooltb.Name = "t4spooltb";
            this.t4spooltb.Size = new System.Drawing.Size(132, 20);
            this.t4spooltb.TabIndex = 24;
            this.toolTip1.SetToolTip(this.t4spooltb, "This can be a single digit or up to 7 digits, leading zeros will be added automat" +
        "ically.");
            // 
            // t4jobtb
            // 
            this.t4jobtb.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.t4jobtb.Location = new System.Drawing.Point(39, 37);
            this.t4jobtb.Name = "t4jobtb";
            this.t4jobtb.Size = new System.Drawing.Size(130, 20);
            this.t4jobtb.TabIndex = 23;
            this.toolTip1.SetToolTip(this.t4jobtb, "This can be the full Location and Job String or just the job number, with or with" +
        "out the leading 0\'s");
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Enabled = true;
            this.timer3.Interval = 500;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 500;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // mtoDataSet1
            // 
            this.mtoDataSet1.DataSetName = "MTODataSet";
            this.mtoDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pD_EDWDataSet1
            // 
            this.pD_EDWDataSet1.DataSetName = "PD_EDWDataSet1";
            this.pD_EDWDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pD_EDWDataSet11
            // 
            this.pD_EDWDataSet11.DataSetName = "PD_EDWDataSet1";
            this.pD_EDWDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pD_EDWDataSet12
            // 
            this.pD_EDWDataSet12.DataSetName = "PD_EDWDataSet1";
            this.pD_EDWDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mtoDataSet2
            // 
            this.mtoDataSet2.DataSetName = "MTODataSet";
            this.mtoDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemCodeDataGridViewTextBoxColumn
            // 
            this.itemCodeDataGridViewTextBoxColumn.DataPropertyName = "ItemCode";
            this.itemCodeDataGridViewTextBoxColumn.HeaderText = "ItemCode";
            this.itemCodeDataGridViewTextBoxColumn.Name = "itemCodeDataGridViewTextBoxColumn";
            this.itemCodeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // specBindingSource
            // 
            this.specBindingSource.DataMember = "Spec";
            this.specBindingSource.DataSource = this.pD_EDWDataSet;
            // 
            // pD_EDWDataSet
            // 
            this.pD_EDWDataSet.DataSetName = "PD_EDWDataSet";
            this.pD_EDWDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // jDEItemMasterBindingSource
            // 
            this.jDEItemMasterBindingSource.DataMember = "JDEItemMaster";
            this.jDEItemMasterBindingSource.DataSource = this.pD_EDWDataSet;
            this.jDEItemMasterBindingSource.CurrentChanged += new System.EventHandler(this.jDEItemMasterBindingSource_CurrentChanged);
            // 
            // specTableAdapter
            // 
            this.specTableAdapter.ClearBeforeFill = true;
            // 
            // jDEItemMasterTableAdapter
            // 
            this.jDEItemMasterTableAdapter.ClearBeforeFill = true;
            // 
            // pDEDWDataSetBindingSource
            // 
            this.pDEDWDataSetBindingSource.DataSource = this.pD_EDWDataSet;
            this.pDEDWDataSetBindingSource.Position = 0;
            // 
            // Form1
            // 
            this.AcceptButton = this.t1add;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 711);
            this.Controls.Add(this.tabcontrol);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Item Upload Tool";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabcontrol.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t1imtable)).EndInit();
            this.t1importcm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.t1addclearcm.ResumeLayout(false);
            this.t1addcm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.t2importsupt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.t2addclearcm.ResumeLayout(false);
            this.t2addcm.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t3breakout)).EndInit();
            this.t3importfibreakout.ResumeLayout(false);
            this.t3copyjdedesc.ResumeLayout(false);
            this.t3importfromimport.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.t4BarcodeBomList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.t4dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mtoDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mtoDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.specBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pD_EDWDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jDEItemMasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pDEDWDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabcontrol;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label t1desclbl;
        private System.Windows.Forms.Label t1pcodelbl;
        private System.Windows.Forms.TextBox t1desc;
        private System.Windows.Forms.TextBox t1pcode;
        private System.Windows.Forms.Label t1salbl;
        private System.Windows.Forms.Label t1wtlbl;
        private System.Windows.Forms.Label t1gllbl;
        private System.Windows.Forms.Label t1matlbl;
        private System.Windows.Forms.TextBox t1sa;
        private System.Windows.Forms.TextBox t1wt;
        private System.Windows.Forms.TextBox t1gl;
        private System.Windows.Forms.TextBox t1mat;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Action;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemorBranch;
        private System.Windows.Forms.DataGridViewTextBoxColumn branchplant;
        private System.Windows.Forms.DataGridViewTextBoxColumn shortid;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn thirditemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionone;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptiontwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn searchtext;
        private System.Windows.Forms.DataGridViewTextBoxColumn comm;
        private System.Windows.Forms.DataGridViewTextBoxColumn subcomm;
        private System.Windows.Forms.DataGridViewTextBoxColumn sizeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn sizetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn sched;
        private System.Windows.Forms.DataGridViewTextBoxColumn ratgec;
        private System.Windows.Forms.DataGridViewTextBoxColumn specgrade;
        private System.Windows.Forms.DataGridViewTextBoxColumn laborgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn mtlgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn pbcodeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn pbcodetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn pbcodethree;
        private System.Windows.Forms.DataGridViewTextBoxColumn uom;
        private System.Windows.Forms.DataGridViewTextBoxColumn wtum;
        private System.Windows.Forms.DataGridViewTextBoxColumn voluom;
        private System.Windows.Forms.DataGridViewTextBoxColumn classcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn lotproctype;
        private System.Windows.Forms.DataGridViewTextBoxColumn countryreqd;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockingtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn lnty;
        private System.Windows.Forms.DataGridViewTextBoxColumn shelfdays;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn surfacearea;
        private System.Windows.Forms.DataGridViewTextBoxColumn templateid;
        private System.Windows.Forms.DataGridViewTextBoxColumn projmfgreqd;
        private System.Windows.Forms.ComboBox t1template;
        private System.Windows.Forms.Label t2desclbl;
        private System.Windows.Forms.Label t2pcodelbl;
        private System.Windows.Forms.TextBox t2desc;
        private System.Windows.Forms.TextBox t2pcode;
        private System.Windows.Forms.Label t2salbl;
        private System.Windows.Forms.Label t2wtlbl;
        private System.Windows.Forms.Label t2gllbl;
        private System.Windows.Forms.Label t2matlbl;
        private System.Windows.Forms.TextBox t2sa;
        private System.Windows.Forms.TextBox t2wt;
        private System.Windows.Forms.TextBox t2mat;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2Action;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2ItemorBranch;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2branchplant;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2shortid;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2itemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2thirditemnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2descriptionone;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2descriptiontwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2searchtext;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2comm;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2subcomm;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2sizeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2sizetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2sched;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2ratgec;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2specgrade;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2laborgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2mtlgrp;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2pbcodeone;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2pbcodetwo;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2pbcodethree;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2uom;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2wtum;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2voluom;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2classcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2lotproctype;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2countryreqd;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2stockingtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2lnty;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2shelfdays;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2weightprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2surfacearea;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2templateid;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2projmfgreqd;
        private System.Windows.Forms.Label t2convertlbl;
        private System.Windows.Forms.Button t1reset;
        private System.Windows.Forms.Button t1copy;
        private System.Windows.Forms.Button t1undoadd;
        private System.Windows.Forms.Button t1addclear;
        private System.Windows.Forms.Button t1undosort;
        private System.Windows.Forms.Button t1add;
        private System.Windows.Forms.Button t2add;
        private System.Windows.Forms.Button t2copy;
        private System.Windows.Forms.Button t2reset;
        private System.Windows.Forms.Button t2undoadd;
        private System.Windows.Forms.Button t2undosort;
        private System.Windows.Forms.Button t2addclear;
        private System.Windows.Forms.Button t1cleardata;
        private System.Windows.Forms.Button t2cleardata;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.TextBox t2gl;
        public System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label t1matlabel;
        private System.Windows.Forms.TextBox tboxmat;
        private System.Windows.Forms.Label t1ratinglabel;
        private System.Windows.Forms.TextBox tboxrating;
        private System.Windows.Forms.Label t1schlabel;
        private System.Windows.Forms.TextBox tboxsch;
        private System.Windows.Forms.Label t1size2label;
        private System.Windows.Forms.TextBox tboxsize2;
        private System.Windows.Forms.Label t1size1label;
        private System.Windows.Forms.TextBox tboxsize1;
        private System.Windows.Forms.Label t1subcomlabel;
        private System.Windows.Forms.TextBox tboxsubcom;
        private System.Windows.Forms.Label t1comlabel;
        private System.Windows.Forms.TextBox tboxcom;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox t1desccheckbox;
        private System.Windows.Forms.ComboBox t1missingitems;
        private System.Windows.Forms.DataGridView t1imtable;
        private PD_EDWDataSet pD_EDWDataSet;
        private System.Windows.Forms.BindingSource specBindingSource;
        private PD_EDWDataSetTableAdapters.SpecTableAdapter specTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.ContextMenuStrip t1addcm;
        private System.Windows.Forms.ToolStripMenuItem addAsCorrection04ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip t1addclearcm;
        private System.Windows.Forms.ContextMenuStrip t2addclearcm;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ContextMenuStrip t2addcm;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addAsCorrection04ToolStripMenuItem1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button t3pasteandcheckbutton;
        private System.Windows.Forms.Button t3clear;
        private System.Windows.Forms.Button t3selectallandcopy;
        private System.Windows.Forms.Button t3pasteandbreakout;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ContextMenuStrip t1importcm;
        private System.Windows.Forms.ToolStripMenuItem importFromClipboardToolStripMenuItem;
        private System.Windows.Forms.DataGridView t3breakout;
        private System.Windows.Forms.ContextMenuStrip t3importfromimport;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ContextMenuStrip t3importfibreakout;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ComboBox t2listfromclip;
        private System.Windows.Forms.Button t2importfromclip;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem copyAsReqToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.BindingSource jDEItemMasterBindingSource;
        private PD_EDWDataSetTableAdapters.JDEItemMasterTableAdapter jDEItemMasterTableAdapter;
        private System.Windows.Forms.BindingSource pDEDWDataSetBindingSource;
        private PD_EDWDataSet1 pD_EDWDataSet1;
        private System.Windows.Forms.Label t2qtylabel;
        private System.Windows.Forms.TextBox t2qtytextbox;
        private System.Windows.Forms.TextBox t2jobnumbertextbox;
        private System.Windows.Forms.CheckBox t2reqcheckbox;
        private System.Windows.Forms.Label t2jobnumberlabel;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2reqbuilder1;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2reqbuilder2;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2reqbuilder3;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2reqbuilder4;
        private System.Windows.Forms.DataGridViewTextBoxColumn t2reqbuilder5;
        private System.Windows.Forms.Label t2reflabel;
        private System.Windows.Forms.TextBox t2reftextbox;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.ToolStripMenuItem importFromClipboardSIDMGLWtSAToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip t3copyjdedesc;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ContextMenuStrip t2importsupt;
        private System.Windows.Forms.ToolStripMenuItem importFromClipboardDescMatGLWtSAToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.ToolStripMenuItem importFromFileToolStripMenuItem;
        private System.Windows.Forms.Button ChkDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn t3subcom;
        private System.Windows.Forms.DataGridViewTextBoxColumn t3size1;
        private System.Windows.Forms.DataGridViewTextBoxColumn t3size2;
        private System.Windows.Forms.DataGridViewTextBoxColumn t3sch;
        private System.Windows.Forms.DataGridViewTextBoxColumn t3rating;
        private System.Windows.Forms.DataGridViewTextBoxColumn t3sgc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Desc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Partcode;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.DataGridView t4dgv;
        private System.Windows.Forms.TextBox t4spooltb;
        private System.Windows.Forms.TextBox t4jobtb;
        private PD_EDWDataSet1 pD_EDWDataSet11;
        private MTODataSet mtoDataSet1;
        private PD_EDWDataSet1 pD_EDWDataSet12;
        private MTODataSet mtoDataSet2;
        private System.Windows.Forms.Button T4LoadBom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox t4refdwgtb;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button t4LoadBomBarcodes;
        private System.Windows.Forms.Button t4ClearList;
        private System.Windows.Forms.Button t4AddToList;
        private System.Windows.Forms.DataGridView t4BarcodeBomList;
        private System.Windows.Forms.DataGridViewTextBoxColumn bcodes;
        private System.Windows.Forms.Button t4ClearData;
        private System.Windows.Forms.DataGridViewTextBoxColumn t4trans;
        private System.Windows.Forms.DataGridViewTextBoxColumn t4iso;
        private System.Windows.Forms.DataGridViewTextBoxColumn SPEC;
        private System.Windows.Forms.DataGridViewTextBoxColumn t4itemcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn t4clientdesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn t4qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn t4pcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn t4desc;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton t4rb2;
        private System.Windows.Forms.RadioButton t4rb1;
        private System.Windows.Forms.CheckBox t1TagItemCB;
    }
}

