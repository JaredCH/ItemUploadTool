﻿namespace ItemUploadTool
{


    partial class PD_EDWDataSet1
    {
    }
}

namespace ItemUploadTool.PD_EDWDataSet1TableAdapters {
    
    
    public partial class JDEItemMasterTableAdapter {
    }
}
